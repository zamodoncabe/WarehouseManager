﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WarehouseManager.Data.DataModels;

namespace WarehouseManager.Data
{

    public class DataContext : DbContext
    {
        public DbSet<Supplier> Suppliers { get; set; }

        private readonly IConfiguration _configuration;
        public DataContext(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public new DbSet<TEntity> Set<TEntity>() where TEntity : class
        {
            return base.Set<TEntity>();
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            var conn = new Extensions().GetConnectionString(_configuration);
            optionsBuilder.UseSqlServer(new SqlConnection(conn));
        }
    }
}
