﻿using Microsoft.Extensions.Configuration;

namespace WarehouseManager.Data
{
    public class Extensions
    {
        public static string? connectionString { get; set; }

        public string GetConnectionString (IConfiguration _configuration)
        {

           return _configuration.GetConnectionString("DefaultConn");
        }

    }
}