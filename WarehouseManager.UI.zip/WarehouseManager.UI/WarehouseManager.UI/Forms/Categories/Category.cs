﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WarehouseManager.UI.Forms.Categories
{
    public partial class Category : Form
    {
        public Category()
        {
            InitializeComponent();
        }

        private void aloneTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Category_Load(object sender, EventArgs e)
        {

        }

        private void AddCategory_Click(object sender, EventArgs e)
        {
            AddCategory catg = new AddCategory();
            catg.Show();
        }
    }
}
