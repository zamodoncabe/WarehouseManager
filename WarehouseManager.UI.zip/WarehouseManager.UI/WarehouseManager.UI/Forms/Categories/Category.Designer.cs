﻿namespace WarehouseManager.UI.Forms.Categories
{
    partial class Category
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Category));
            poisonDataGridView1 = new ReaLTaiizor.Controls.PoisonDataGridView();
            CategoryID = new DataGridViewTextBoxColumn();
            CategoryName = new DataGridViewTextBoxColumn();
            Description = new DataGridViewTextBoxColumn();
            Picture = new DataGridViewImageColumn();
            AddCategory = new ReaLTaiizor.Controls.HopeRoundButton();
            AditCategory = new ReaLTaiizor.Controls.HopeRoundButton();
            DeleteCategory = new ReaLTaiizor.Controls.HopeRoundButton();
            bigLabel1 = new ReaLTaiizor.Controls.BigLabel();
            backButton = new Label();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            label2 = new Label();
            smallTextBox1 = new ReaLTaiizor.Controls.SmallTextBox();
            ((System.ComponentModel.ISupportInitialize)poisonDataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // poisonDataGridView1
            // 
            poisonDataGridView1.AllowUserToResizeRows = false;
            poisonDataGridView1.BackgroundColor = Color.FromArgb(224, 224, 224);
            poisonDataGridView1.BorderStyle = BorderStyle.None;
            poisonDataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.None;
            poisonDataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = Color.FromArgb(0, 174, 219);
            dataGridViewCellStyle4.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = Color.FromArgb(255, 255, 255);
            dataGridViewCellStyle4.SelectionBackColor = Color.FromArgb(0, 198, 247);
            dataGridViewCellStyle4.SelectionForeColor = Color.FromArgb(17, 17, 17);
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            poisonDataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            poisonDataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            poisonDataGridView1.Columns.AddRange(new DataGridViewColumn[] { CategoryID, CategoryName, Description, Picture });
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = Color.FromArgb(255, 255, 255);
            dataGridViewCellStyle5.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            dataGridViewCellStyle5.ForeColor = Color.FromArgb(136, 136, 136);
            dataGridViewCellStyle5.SelectionBackColor = Color.FromArgb(0, 198, 247);
            dataGridViewCellStyle5.SelectionForeColor = Color.FromArgb(17, 17, 17);
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.False;
            poisonDataGridView1.DefaultCellStyle = dataGridViewCellStyle5;
            poisonDataGridView1.EnableHeadersVisualStyles = false;
            poisonDataGridView1.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            poisonDataGridView1.GridColor = Color.FromArgb(255, 255, 255);
            poisonDataGridView1.Location = new Point(12, 195);
            poisonDataGridView1.Name = "poisonDataGridView1";
            poisonDataGridView1.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = Color.FromArgb(0, 174, 219);
            dataGridViewCellStyle6.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            dataGridViewCellStyle6.ForeColor = Color.FromArgb(255, 255, 255);
            dataGridViewCellStyle6.SelectionBackColor = Color.FromArgb(0, 198, 247);
            dataGridViewCellStyle6.SelectionForeColor = Color.FromArgb(17, 17, 17);
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.True;
            poisonDataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            poisonDataGridView1.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            poisonDataGridView1.RowTemplate.Height = 25;
            poisonDataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            poisonDataGridView1.Size = new Size(625, 209);
            poisonDataGridView1.TabIndex = 1;
            // 
            // CategoryID
            // 
            CategoryID.HeaderText = "CategoryID";
            CategoryID.Name = "CategoryID";
            // 
            // CategoryName
            // 
            CategoryName.HeaderText = "CategoryName";
            CategoryName.Name = "CategoryName";
            // 
            // Description
            // 
            Description.HeaderText = "Description";
            Description.Name = "Description";
            // 
            // Picture
            // 
            Picture.HeaderText = "Picture";
            Picture.Name = "Picture";
            // 
            // AddCategory
            // 
            AddCategory.BorderColor = Color.FromArgb(220, 223, 230);
            AddCategory.ButtonType = ReaLTaiizor.Util.HopeButtonType.Primary;
            AddCategory.DangerColor = Color.FromArgb(245, 108, 108);
            AddCategory.DefaultColor = Color.FromArgb(255, 255, 255);
            AddCategory.Font = new Font("Segoe UI Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            AddCategory.HoverTextColor = Color.FromArgb(48, 49, 51);
            AddCategory.InfoColor = Color.FromArgb(144, 147, 153);
            AddCategory.Location = new Point(226, 139);
            AddCategory.Name = "AddCategory";
            AddCategory.PrimaryColor = Color.FromArgb(0, 192, 0);
            AddCategory.Size = new Size(122, 32);
            AddCategory.SuccessColor = Color.FromArgb(103, 194, 58);
            AddCategory.TabIndex = 12;
            AddCategory.Text = "Add Category";
            AddCategory.TextColor = Color.White;
            AddCategory.WarningColor = Color.FromArgb(230, 162, 60);
            AddCategory.Click += AddCategory_Click;
            // 
            // AditCategory
            // 
            AditCategory.BorderColor = Color.FromArgb(220, 223, 230);
            AditCategory.ButtonType = ReaLTaiizor.Util.HopeButtonType.Primary;
            AditCategory.DangerColor = Color.FromArgb(245, 108, 108);
            AditCategory.DefaultColor = Color.FromArgb(255, 255, 255);
            AditCategory.Font = new Font("Segoe UI Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            AditCategory.HoverTextColor = Color.FromArgb(48, 49, 51);
            AditCategory.InfoColor = Color.FromArgb(144, 147, 153);
            AditCategory.Location = new Point(368, 139);
            AditCategory.Name = "AditCategory";
            AditCategory.PrimaryColor = Color.FromArgb(255, 128, 0);
            AditCategory.Size = new Size(122, 32);
            AditCategory.SuccessColor = Color.FromArgb(103, 194, 58);
            AditCategory.TabIndex = 13;
            AditCategory.Text = "Edit Category";
            AditCategory.TextColor = Color.White;
            AditCategory.WarningColor = Color.FromArgb(230, 162, 60);
            // 
            // DeleteCategory
            // 
            DeleteCategory.BorderColor = Color.FromArgb(220, 223, 230);
            DeleteCategory.ButtonType = ReaLTaiizor.Util.HopeButtonType.Primary;
            DeleteCategory.DangerColor = Color.FromArgb(245, 108, 108);
            DeleteCategory.DefaultColor = Color.FromArgb(255, 255, 255);
            DeleteCategory.Font = new Font("Segoe UI Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            DeleteCategory.HoverTextColor = Color.FromArgb(48, 49, 51);
            DeleteCategory.InfoColor = Color.FromArgb(144, 147, 153);
            DeleteCategory.Location = new Point(510, 139);
            DeleteCategory.Name = "DeleteCategory";
            DeleteCategory.PrimaryColor = Color.FromArgb(192, 0, 0);
            DeleteCategory.Size = new Size(122, 32);
            DeleteCategory.SuccessColor = Color.FromArgb(103, 194, 58);
            DeleteCategory.TabIndex = 14;
            DeleteCategory.Text = "Delete Category";
            DeleteCategory.TextColor = Color.White;
            DeleteCategory.WarningColor = Color.FromArgb(230, 162, 60);
            // 
            // bigLabel1
            // 
            bigLabel1.AutoSize = true;
            bigLabel1.BackColor = Color.Transparent;
            bigLabel1.Font = new Font("Segoe UI Semibold", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            bigLabel1.ForeColor = Color.FromArgb(80, 80, 80);
            bigLabel1.Location = new Point(5, 127);
            bigLabel1.Name = "bigLabel1";
            bigLabel1.Size = new Size(147, 37);
            bigLabel1.TabIndex = 15;
            bigLabel1.Text = "Categories";
            // 
            // backButton
            // 
            backButton.AutoSize = true;
            backButton.Cursor = Cursors.Hand;
            backButton.Location = new Point(12, 11);
            backButton.Name = "backButton";
            backButton.Size = new Size(32, 15);
            backButton.TabIndex = 16;
            backButton.Text = "back";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Cursor = Cursors.Hand;
            label1.Location = new Point(12, 162);
            label1.Name = "label1";
            label1.Size = new Size(106, 15);
            label1.TabIndex = 17;
            label1.Text = "product categories";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(432, 55);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(30, 28);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 38;
            pictureBox1.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Cursor = Cursors.Hand;
            label2.Location = new Point(468, 37);
            label2.Name = "label2";
            label2.Size = new Size(90, 15);
            label2.TabIndex = 37;
            label2.Text = "search category";
            // 
            // smallTextBox1
            // 
            smallTextBox1.BackColor = Color.Transparent;
            smallTextBox1.BorderColor = Color.FromArgb(180, 180, 180);
            smallTextBox1.CustomBGColor = Color.White;
            smallTextBox1.Font = new Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point);
            smallTextBox1.ForeColor = Color.DimGray;
            smallTextBox1.Location = new Point(468, 55);
            smallTextBox1.MaxLength = 32767;
            smallTextBox1.Multiline = false;
            smallTextBox1.Name = "smallTextBox1";
            smallTextBox1.ReadOnly = false;
            smallTextBox1.Size = new Size(164, 28);
            smallTextBox1.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            smallTextBox1.TabIndex = 36;
            smallTextBox1.TextAlignment = HorizontalAlignment.Left;
            smallTextBox1.UseSystemPasswordChar = false;
            // 
            // Category
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(649, 416);
            Controls.Add(pictureBox1);
            Controls.Add(label2);
            Controls.Add(smallTextBox1);
            Controls.Add(backButton);
            Controls.Add(bigLabel1);
            Controls.Add(DeleteCategory);
            Controls.Add(AditCategory);
            Controls.Add(AddCategory);
            Controls.Add(poisonDataGridView1);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Category";
            Text = "Category";
            Load += Category_Load;
            ((System.ComponentModel.ISupportInitialize)poisonDataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ReaLTaiizor.Controls.PoisonDataGridView poisonDataGridView1;
        private Button button1;
        private ReaLTaiizor.Controls.SkyButton skyButton1;
        private ReaLTaiizor.Controls.ThunderButton thunderButton1;
        private ReaLTaiizor.Controls.SpaceButton spaceButton1;
        private ReaLTaiizor.Controls.ParrotSuperButton parrotSuperButton2;
        private ReaLTaiizor.Controls.NightButton nightButton1;
        private ReaLTaiizor.Controls.MoonButton moonButton1;
        private ReaLTaiizor.Controls.MoonRadioButton moonRadioButton1;
        private ReaLTaiizor.Controls.MetroDefaultButton metroDefaultButton1;
        private ReaLTaiizor.Controls.HopeRoundButton AddCategory;
        private ReaLTaiizor.Controls.HopeRoundButton AditCategory;
        private ReaLTaiizor.Controls.HopeRoundButton DeleteCategory;
        private ReaLTaiizor.Controls.BigLabel bigLabel1;
        private Label backButton;
        private Label label1;
        private DataGridViewTextBoxColumn CategoryID;
        private DataGridViewTextBoxColumn CategoryName;
        private DataGridViewTextBoxColumn Description;
        private DataGridViewImageColumn Picture;
        private PictureBox pictureBox1;
        private Label label2;
        private ReaLTaiizor.Controls.SmallTextBox smallTextBox1;
    }
}