﻿namespace WarehouseManager.UI.Forms.Categories
{
    partial class AddCategory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            CategoryName = new ReaLTaiizor.Controls.BigTextBox();
            Description = new ReaLTaiizor.Controls.BigTextBox();
            label1 = new Label();
            metroControlBox1 = new ReaLTaiizor.Controls.MetroControlBox();
            openFileDialog1 = new OpenFileDialog();
            productPicture = new ReaLTaiizor.Controls.AirButton();
            CategoryBtn = new ReaLTaiizor.Controls.HopeRoundButton();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            panel1 = new Panel();
            label5 = new Label();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // CategoryName
            // 
            CategoryName.BackColor = Color.Transparent;
            CategoryName.Font = new Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point);
            CategoryName.ForeColor = Color.DimGray;
            CategoryName.Image = null;
            CategoryName.Location = new Point(24, 157);
            CategoryName.MaxLength = 32767;
            CategoryName.Multiline = false;
            CategoryName.Name = "CategoryName";
            CategoryName.ReadOnly = false;
            CategoryName.Size = new Size(326, 41);
            CategoryName.TabIndex = 0;
            CategoryName.TextAlignment = HorizontalAlignment.Left;
            CategoryName.UseSystemPasswordChar = false;
            // 
            // Description
            // 
            Description.BackColor = Color.Transparent;
            Description.Font = new Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point);
            Description.ForeColor = Color.DimGray;
            Description.Image = null;
            Description.Location = new Point(24, 231);
            Description.MaxLength = 32767;
            Description.Multiline = false;
            Description.Name = "Description";
            Description.ReadOnly = false;
            Description.Size = new Size(326, 41);
            Description.TabIndex = 1;
            Description.TextAlignment = HorizontalAlignment.Left;
            Description.UseSystemPasswordChar = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 17.25F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(113, 72);
            label1.Name = "label1";
            label1.Size = new Size(159, 31);
            label1.TabIndex = 5;
            label1.Text = "Add Category";
            // 
            // metroControlBox1
            // 
            metroControlBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            metroControlBox1.CloseHoverBackColor = Color.FromArgb(183, 40, 40);
            metroControlBox1.CloseHoverForeColor = Color.White;
            metroControlBox1.CloseNormalForeColor = Color.Gray;
            metroControlBox1.DefaultLocation = ReaLTaiizor.Enum.Metro.LocationType.Normal;
            metroControlBox1.DisabledForeColor = Color.DimGray;
            metroControlBox1.IsDerivedStyle = true;
            metroControlBox1.Location = new Point(263, 3);
            metroControlBox1.MaximizeBox = true;
            metroControlBox1.MaximizeHoverBackColor = Color.FromArgb(238, 238, 238);
            metroControlBox1.MaximizeHoverForeColor = Color.Gray;
            metroControlBox1.MaximizeNormalForeColor = Color.Gray;
            metroControlBox1.MinimizeBox = true;
            metroControlBox1.MinimizeHoverBackColor = Color.FromArgb(238, 238, 238);
            metroControlBox1.MinimizeHoverForeColor = Color.Gray;
            metroControlBox1.MinimizeNormalForeColor = Color.Gray;
            metroControlBox1.Name = "metroControlBox1";
            metroControlBox1.Size = new Size(100, 25);
            metroControlBox1.Style = ReaLTaiizor.Enum.Metro.Style.Light;
            metroControlBox1.StyleManager = null;
            metroControlBox1.TabIndex = 6;
            metroControlBox1.Text = "metroControlBox1";
            metroControlBox1.ThemeAuthor = "Taiizor";
            metroControlBox1.ThemeName = "MetroLight";
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            // 
            // productPicture
            // 
            productPicture.Customization = "7e3t//Ly8v/r6+v/5ubm/+vr6//f39//p6en/zw8PP8UFBT/gICA/w==";
            productPicture.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            productPicture.Image = null;
            productPicture.Location = new Point(24, 303);
            productPicture.Name = "productPicture";
            productPicture.NoRounding = false;
            productPicture.Size = new Size(150, 30);
            productPicture.TabIndex = 7;
            productPicture.Text = "Select Picture";
            productPicture.Transparent = false;
            // 
            // CategoryBtn
            // 
            CategoryBtn.BorderColor = Color.FromArgb(220, 223, 230);
            CategoryBtn.ButtonType = ReaLTaiizor.Util.HopeButtonType.Primary;
            CategoryBtn.DangerColor = Color.FromArgb(245, 108, 108);
            CategoryBtn.DefaultColor = Color.FromArgb(255, 255, 255);
            CategoryBtn.Font = new Font("Segoe UI Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            CategoryBtn.HoverTextColor = Color.FromArgb(48, 49, 51);
            CategoryBtn.InfoColor = Color.FromArgb(144, 147, 153);
            CategoryBtn.Location = new Point(228, 396);
            CategoryBtn.Name = "CategoryBtn";
            CategoryBtn.PrimaryColor = Color.Green;
            CategoryBtn.Size = new Size(122, 32);
            CategoryBtn.SuccessColor = Color.FromArgb(103, 194, 58);
            CategoryBtn.TabIndex = 13;
            CategoryBtn.Text = "Submit";
            CategoryBtn.TextColor = Color.White;
            CategoryBtn.WarningColor = Color.FromArgb(230, 162, 60);
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(24, 139);
            label2.Name = "label2";
            label2.Size = new Size(88, 15);
            label2.TabIndex = 14;
            label2.Text = "Category name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(24, 213);
            label3.Name = "label3";
            label3.Size = new Size(117, 15);
            label3.TabIndex = 15;
            label3.Text = "Category description";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(24, 285);
            label4.Name = "label4";
            label4.Size = new Size(120, 15);
            label4.TabIndex = 16;
            label4.Text = "Add Category picture";
            // 
            // panel1
            // 
            panel1.BackColor = Color.Gainsboro;
            panel1.Controls.Add(label5);
            panel1.Controls.Add(metroControlBox1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(374, 34);
            panel1.TabIndex = 17;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 9);
            label5.Name = "label5";
            label5.Size = new Size(55, 15);
            label5.TabIndex = 18;
            label5.Text = "Category";
            // 
            // AddCategory
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(374, 460);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(CategoryBtn);
            Controls.Add(productPicture);
            Controls.Add(label1);
            Controls.Add(Description);
            Controls.Add(CategoryName);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "AddCategory";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "AddCategory";
            Load += AddCategory_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ReaLTaiizor.Controls.BigTextBox CategoryName;
        private ReaLTaiizor.Controls.BigTextBox Description;
        private Label label1;
        private ReaLTaiizor.Controls.MetroControlBox metroControlBox1;
        private OpenFileDialog openFileDialog1;
        private ReaLTaiizor.Controls.AirButton productPicture;
        private ReaLTaiizor.Controls.HopeRoundButton CategoryBtn;
        private Label label2;
        private Label label3;
        private Label label4;
        private Panel panel1;
        private Label label5;
    }
}