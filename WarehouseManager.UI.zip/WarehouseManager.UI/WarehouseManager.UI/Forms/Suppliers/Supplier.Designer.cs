﻿namespace WarehouseManager.UI.Forms.Suppliers
{
    partial class Supplier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle7 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle8 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle9 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Supplier));
            backButton = new Label();
            bigLabel1 = new ReaLTaiizor.Controls.BigLabel();
            DeleteSupplier = new ReaLTaiizor.Controls.HopeRoundButton();
            AditSupplier = new ReaLTaiizor.Controls.HopeRoundButton();
            AddSupplier = new ReaLTaiizor.Controls.HopeRoundButton();
            SupplierDataGridView = new ReaLTaiizor.Controls.PoisonDataGridView();
            SupplierID = new DataGridViewTextBoxColumn();
            CompanyName = new DataGridViewTextBoxColumn();
            ContactName = new DataGridViewTextBoxColumn();
            ContactTitle = new DataGridViewTextBoxColumn();
            Address = new DataGridViewTextBoxColumn();
            City = new DataGridViewTextBoxColumn();
            Region = new DataGridViewTextBoxColumn();
            PostalCode = new DataGridViewTextBoxColumn();
            Country = new DataGridViewTextBoxColumn();
            Phone = new DataGridViewTextBoxColumn();
            Fax = new DataGridViewTextBoxColumn();
            HomePage = new DataGridViewTextBoxColumn();
            label1 = new Label();
            smallTextBox1 = new ReaLTaiizor.Controls.SmallTextBox();
            label2 = new Label();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)SupplierDataGridView).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // backButton
            // 
            backButton.AutoSize = true;
            backButton.BackColor = Color.Transparent;
            backButton.Cursor = Cursors.Hand;
            backButton.Location = new Point(18, 12);
            backButton.Name = "backButton";
            backButton.Size = new Size(32, 15);
            backButton.TabIndex = 30;
            backButton.Text = "back";
            backButton.Click += backButton_Click;
            // 
            // bigLabel1
            // 
            bigLabel1.AutoSize = true;
            bigLabel1.BackColor = Color.Transparent;
            bigLabel1.Font = new Font("Segoe UI Semibold", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            bigLabel1.ForeColor = Color.FromArgb(80, 80, 80);
            bigLabel1.Location = new Point(18, 85);
            bigLabel1.Name = "bigLabel1";
            bigLabel1.Size = new Size(130, 37);
            bigLabel1.TabIndex = 29;
            bigLabel1.Text = "Suppliers";
            // 
            // DeleteSupplier
            // 
            DeleteSupplier.BorderColor = Color.FromArgb(220, 223, 230);
            DeleteSupplier.ButtonType = ReaLTaiizor.Util.HopeButtonType.Primary;
            DeleteSupplier.DangerColor = Color.FromArgb(245, 108, 108);
            DeleteSupplier.DefaultColor = Color.FromArgb(255, 255, 255);
            DeleteSupplier.Font = new Font("Segoe UI Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            DeleteSupplier.HoverTextColor = Color.FromArgb(48, 49, 51);
            DeleteSupplier.InfoColor = Color.FromArgb(144, 147, 153);
            DeleteSupplier.Location = new Point(516, 99);
            DeleteSupplier.Name = "DeleteSupplier";
            DeleteSupplier.PrimaryColor = Color.FromArgb(192, 0, 0);
            DeleteSupplier.Size = new Size(122, 32);
            DeleteSupplier.SuccessColor = Color.FromArgb(103, 194, 58);
            DeleteSupplier.TabIndex = 28;
            DeleteSupplier.Text = "Delete Supplier";
            DeleteSupplier.TextColor = Color.White;
            DeleteSupplier.WarningColor = Color.FromArgb(230, 162, 60);
            // 
            // AditSupplier
            // 
            AditSupplier.BorderColor = Color.FromArgb(220, 223, 230);
            AditSupplier.ButtonType = ReaLTaiizor.Util.HopeButtonType.Primary;
            AditSupplier.DangerColor = Color.FromArgb(245, 108, 108);
            AditSupplier.DefaultColor = Color.FromArgb(255, 255, 255);
            AditSupplier.Font = new Font("Segoe UI Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            AditSupplier.HoverTextColor = Color.FromArgb(48, 49, 51);
            AditSupplier.InfoColor = Color.FromArgb(144, 147, 153);
            AditSupplier.Location = new Point(374, 99);
            AditSupplier.Name = "AditSupplier";
            AditSupplier.PrimaryColor = Color.FromArgb(255, 128, 0);
            AditSupplier.Size = new Size(122, 32);
            AditSupplier.SuccessColor = Color.FromArgb(103, 194, 58);
            AditSupplier.TabIndex = 27;
            AditSupplier.Text = "Edit Supplier";
            AditSupplier.TextColor = Color.White;
            AditSupplier.WarningColor = Color.FromArgb(230, 162, 60);
            // 
            // AddSupplier
            // 
            AddSupplier.BorderColor = Color.FromArgb(220, 223, 230);
            AddSupplier.ButtonType = ReaLTaiizor.Util.HopeButtonType.Primary;
            AddSupplier.DangerColor = Color.FromArgb(245, 108, 108);
            AddSupplier.DefaultColor = Color.FromArgb(255, 255, 255);
            AddSupplier.Font = new Font("Segoe UI Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            AddSupplier.HoverTextColor = Color.FromArgb(48, 49, 51);
            AddSupplier.InfoColor = Color.FromArgb(144, 147, 153);
            AddSupplier.Location = new Point(232, 99);
            AddSupplier.Name = "AddSupplier";
            AddSupplier.PrimaryColor = Color.FromArgb(0, 192, 0);
            AddSupplier.Size = new Size(122, 32);
            AddSupplier.SuccessColor = Color.FromArgb(103, 194, 58);
            AddSupplier.TabIndex = 26;
            AddSupplier.Text = "Add Supplier";
            AddSupplier.TextColor = Color.White;
            AddSupplier.WarningColor = Color.FromArgb(230, 162, 60);
            AddSupplier.Click += AddSupplier_Click;
            // 
            // SupplierDataGridView
            // 
            SupplierDataGridView.AllowUserToResizeRows = false;
            SupplierDataGridView.BackgroundColor = Color.FromArgb(224, 224, 224);
            SupplierDataGridView.BorderStyle = BorderStyle.None;
            SupplierDataGridView.CellBorderStyle = DataGridViewCellBorderStyle.None;
            SupplierDataGridView.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = Color.FromArgb(0, 174, 219);
            dataGridViewCellStyle7.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            dataGridViewCellStyle7.ForeColor = Color.FromArgb(255, 255, 255);
            dataGridViewCellStyle7.SelectionBackColor = Color.FromArgb(0, 198, 247);
            dataGridViewCellStyle7.SelectionForeColor = Color.FromArgb(17, 17, 17);
            dataGridViewCellStyle7.WrapMode = DataGridViewTriState.True;
            SupplierDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            SupplierDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            SupplierDataGridView.Columns.AddRange(new DataGridViewColumn[] { SupplierID, CompanyName, ContactName, ContactTitle, Address, City, Region, PostalCode, Country, Phone, Fax, HomePage });
            dataGridViewCellStyle8.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = Color.FromArgb(255, 255, 255);
            dataGridViewCellStyle8.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            dataGridViewCellStyle8.ForeColor = Color.FromArgb(136, 136, 136);
            dataGridViewCellStyle8.SelectionBackColor = Color.FromArgb(0, 198, 247);
            dataGridViewCellStyle8.SelectionForeColor = Color.FromArgb(17, 17, 17);
            dataGridViewCellStyle8.WrapMode = DataGridViewTriState.False;
            SupplierDataGridView.DefaultCellStyle = dataGridViewCellStyle8;
            SupplierDataGridView.EnableHeadersVisualStyles = false;
            SupplierDataGridView.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            SupplierDataGridView.GridColor = Color.FromArgb(255, 255, 255);
            SupplierDataGridView.Location = new Point(18, 155);
            SupplierDataGridView.Name = "SupplierDataGridView";
            SupplierDataGridView.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle9.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = Color.FromArgb(0, 174, 219);
            dataGridViewCellStyle9.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            dataGridViewCellStyle9.ForeColor = Color.FromArgb(255, 255, 255);
            dataGridViewCellStyle9.SelectionBackColor = Color.FromArgb(0, 198, 247);
            dataGridViewCellStyle9.SelectionForeColor = Color.FromArgb(17, 17, 17);
            dataGridViewCellStyle9.WrapMode = DataGridViewTriState.True;
            SupplierDataGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            SupplierDataGridView.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            SupplierDataGridView.RowTemplate.Height = 25;
            SupplierDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            SupplierDataGridView.Size = new Size(620, 209);
            SupplierDataGridView.TabIndex = 25;
            SupplierDataGridView.CellContentClick += SupplierDataGridView_CellContentClick;
            // 
            // SupplierID
            // 
            SupplierID.HeaderText = "SupplierID";
            SupplierID.Name = "SupplierID";
            // 
            // CompanyName
            // 
            CompanyName.HeaderText = "Company Name";
            CompanyName.Name = "CompanyName";
            // 
            // ContactName
            // 
            ContactName.HeaderText = "Contact Name";
            ContactName.Name = "ContactName";
            // 
            // ContactTitle
            // 
            ContactTitle.HeaderText = "Contact Title";
            ContactTitle.Name = "ContactTitle";
            // 
            // Address
            // 
            Address.HeaderText = "Address";
            Address.Name = "Address";
            // 
            // City
            // 
            City.HeaderText = "City";
            City.Name = "City";
            // 
            // Region
            // 
            Region.HeaderText = "Region";
            Region.Name = "Region";
            // 
            // PostalCode
            // 
            PostalCode.HeaderText = "PostalCode";
            PostalCode.Name = "PostalCode";
            // 
            // Country
            // 
            Country.HeaderText = "Country";
            Country.Name = "Country";
            // 
            // Phone
            // 
            Phone.HeaderText = "Phone";
            Phone.Name = "Phone";
            // 
            // Fax
            // 
            Fax.HeaderText = "Fax";
            Fax.Name = "Fax";
            // 
            // HomePage
            // 
            HomePage.HeaderText = "HomePage";
            HomePage.Name = "HomePage";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Cursor = Cursors.Hand;
            label1.Location = new Point(18, 122);
            label1.Name = "label1";
            label1.Size = new Size(145, 15);
            label1.TabIndex = 31;
            label1.Text = "manage product suppliers";
            // 
            // smallTextBox1
            // 
            smallTextBox1.BackColor = Color.Transparent;
            smallTextBox1.BorderColor = Color.FromArgb(180, 180, 180);
            smallTextBox1.CustomBGColor = Color.White;
            smallTextBox1.Font = new Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point);
            smallTextBox1.ForeColor = Color.DimGray;
            smallTextBox1.Location = new Point(474, 45);
            smallTextBox1.MaxLength = 32767;
            smallTextBox1.Multiline = false;
            smallTextBox1.Name = "smallTextBox1";
            smallTextBox1.ReadOnly = false;
            smallTextBox1.Size = new Size(164, 28);
            smallTextBox1.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            smallTextBox1.TabIndex = 33;
            smallTextBox1.TextAlignment = HorizontalAlignment.Left;
            smallTextBox1.UseSystemPasswordChar = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Cursor = Cursors.Hand;
            label2.Location = new Point(474, 27);
            label2.Name = "label2";
            label2.Size = new Size(86, 15);
            label2.TabIndex = 34;
            label2.Text = "search supplier";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(438, 45);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(30, 28);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 35;
            pictureBox1.TabStop = false;
            // 
            // Supplier
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(655, 377);
            Controls.Add(pictureBox1);
            Controls.Add(label2);
            Controls.Add(smallTextBox1);
            Controls.Add(backButton);
            Controls.Add(bigLabel1);
            Controls.Add(DeleteSupplier);
            Controls.Add(AditSupplier);
            Controls.Add(AddSupplier);
            Controls.Add(SupplierDataGridView);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Supplier";
            Text = "Suppliers";
            Load += Supplier_Load;
            ((System.ComponentModel.ISupportInitialize)SupplierDataGridView).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label backButton;
        private ReaLTaiizor.Controls.BigLabel bigLabel1;
        private ReaLTaiizor.Controls.HopeRoundButton DeleteSupplier;
        private ReaLTaiizor.Controls.HopeRoundButton AditSupplier;
        private ReaLTaiizor.Controls.HopeRoundButton AddSupplier;
        private ReaLTaiizor.Controls.PoisonDataGridView SupplierDataGridView;
        private Label label1;
        private DataGridViewTextBoxColumn SupplierID;
        private DataGridViewTextBoxColumn CompanyName;
        private DataGridViewTextBoxColumn ContactName;
        private DataGridViewTextBoxColumn ContactTitle;
        private DataGridViewTextBoxColumn Address;
        private DataGridViewTextBoxColumn City;
        private DataGridViewTextBoxColumn Region;
        private DataGridViewTextBoxColumn PostalCode;
        private DataGridViewTextBoxColumn Country;
        private DataGridViewTextBoxColumn Phone;
        private DataGridViewTextBoxColumn Fax;
        private DataGridViewTextBoxColumn HomePage;
        private ReaLTaiizor.Controls.SmallTextBox smallTextBox1;
        private Label label2;
        private PictureBox pictureBox1;
    }
}