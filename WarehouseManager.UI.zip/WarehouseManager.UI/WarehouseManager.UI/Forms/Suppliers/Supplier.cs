﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WarehouseManager.UI.Forms.MainForm;
using WarehouseManager.Repository.Emplementation;



namespace WarehouseManager.UI.Forms.Suppliers
{
    public partial class Supplier : Form
    {
        Repository.Emplementation.Supplier supplier;



        public Supplier()
        {
            InitializeComponent();
        }

        public void backButton_Click(object sender, EventArgs e)
        {
            MainForm.WarehouseManager back = new MainForm.WarehouseManager();
            back.loadform(new Dashboard());


        }

        private void SupplierDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Supplier_Load(object sender, EventArgs e)
        {

            try
            {
                //supplier = new Supplier();
                //SupplierDataGridView.DataSource = supplier.GetSuppliers();
                //SupplierNum.Text = $" Supplier Count: {SupplierDataGridView.RowCount}";

                throw new Exception("not connected");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Custom Exception Caught: " + ex.Message);
            }


        }

        private void AddSupplier_Click(object sender, EventArgs e)
        {
            AddSupplier sup = new AddSupplier();
            sup.Show();
        }
    }
}
