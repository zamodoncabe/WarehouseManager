﻿using WarehouseManager.UI.Forms.MainForm;

namespace WarehouseManager.UI.Forms.Suppliers
{
    internal class loadform : MainForm.WarehouseManager
    {
        private Dashboard dashboard;

        public loadform(Dashboard dashboard)
        {
            this.dashboard = dashboard;
        }
    }
}