﻿namespace WarehouseManager.UI.Forms.Suppliers
{
    partial class AddSupplier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Region = new ReaLTaiizor.Controls.BigTextBox();
            label5 = new Label();
            City = new ReaLTaiizor.Controls.BigTextBox();
            selectSupplier = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            CategoryBtn = new ReaLTaiizor.Controls.HopeRoundButton();
            label1 = new Label();
            CompanyName = new ReaLTaiizor.Controls.BigTextBox();
            panel1 = new Panel();
            metroControlBox3 = new ReaLTaiizor.Controls.MetroControlBox();
            metroControlBox2 = new ReaLTaiizor.Controls.MetroControlBox();
            metroControlBox1 = new ReaLTaiizor.Controls.MetroControlBox();
            ContactName = new ReaLTaiizor.Controls.BigTextBox();
            ContactTitle = new ReaLTaiizor.Controls.BigTextBox();
            Address = new ReaLTaiizor.Controls.BigTextBox();
            PostalCode = new ReaLTaiizor.Controls.BigTextBox();
            Country = new ReaLTaiizor.Controls.BigTextBox();
            Phone = new ReaLTaiizor.Controls.BigTextBox();
            Fax = new ReaLTaiizor.Controls.BigTextBox();
            HomePage = new ReaLTaiizor.Controls.BigTextBox();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // Region
            // 
            Region.BackColor = Color.Transparent;
            Region.Font = new Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point);
            Region.ForeColor = Color.DimGray;
            Region.Image = null;
            Region.Location = new Point(206, 264);
            Region.MaxLength = 32767;
            Region.Multiline = false;
            Region.Name = "Region";
            Region.ReadOnly = false;
            Region.Size = new Size(164, 41);
            Region.TabIndex = 46;
            Region.TextAlignment = HorizontalAlignment.Left;
            Region.UseSystemPasswordChar = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 9);
            label5.Name = "label5";
            label5.Size = new Size(50, 15);
            label5.TabIndex = 45;
            label5.Text = "Supplier";
            // 
            // City
            // 
            City.BackColor = Color.Transparent;
            City.Font = new Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point);
            City.ForeColor = Color.DimGray;
            City.Image = null;
            City.Location = new Point(30, 264);
            City.MaxLength = 32767;
            City.Multiline = false;
            City.Name = "City";
            City.ReadOnly = false;
            City.Size = new Size(159, 41);
            City.TabIndex = 42;
            City.TextAlignment = HorizontalAlignment.Left;
            City.UseSystemPasswordChar = false;
            // 
            // selectSupplier
            // 
            selectSupplier.AutoSize = true;
            selectSupplier.Location = new Point(30, 176);
            selectSupplier.Name = "selectSupplier";
            selectSupplier.Size = new Size(74, 15);
            selectSupplier.TabIndex = 41;
            selectSupplier.Text = "Contact Title";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(30, 246);
            label4.Name = "label4";
            label4.Size = new Size(28, 15);
            label4.TabIndex = 40;
            label4.Text = "City";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(30, 326);
            label3.Name = "label3";
            label3.Size = new Size(50, 15);
            label3.TabIndex = 39;
            label3.Text = "Country";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(30, 104);
            label2.Name = "label2";
            label2.Size = new Size(94, 15);
            label2.TabIndex = 38;
            label2.Text = "Company Name";
            // 
            // CategoryBtn
            // 
            CategoryBtn.BorderColor = Color.FromArgb(220, 223, 230);
            CategoryBtn.ButtonType = ReaLTaiizor.Util.HopeButtonType.Primary;
            CategoryBtn.DangerColor = Color.FromArgb(245, 108, 108);
            CategoryBtn.DefaultColor = Color.FromArgb(255, 255, 255);
            CategoryBtn.Font = new Font("Segoe UI Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            CategoryBtn.HoverTextColor = Color.FromArgb(48, 49, 51);
            CategoryBtn.InfoColor = Color.FromArgb(144, 147, 153);
            CategoryBtn.Location = new Point(430, 469);
            CategoryBtn.Name = "CategoryBtn";
            CategoryBtn.PrimaryColor = Color.Green;
            CategoryBtn.Size = new Size(122, 32);
            CategoryBtn.SuccessColor = Color.FromArgb(103, 194, 58);
            CategoryBtn.TabIndex = 36;
            CategoryBtn.Text = "Submit";
            CategoryBtn.TextColor = Color.White;
            CategoryBtn.WarningColor = Color.FromArgb(230, 162, 60);
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 17.25F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(220, 51);
            label1.Name = "label1";
            label1.Size = new Size(150, 31);
            label1.TabIndex = 35;
            label1.Text = "Add Supplier";
            // 
            // CompanyName
            // 
            CompanyName.BackColor = Color.Transparent;
            CompanyName.Font = new Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point);
            CompanyName.ForeColor = Color.DimGray;
            CompanyName.Image = null;
            CompanyName.Location = new Point(30, 122);
            CompanyName.MaxLength = 32767;
            CompanyName.Multiline = false;
            CompanyName.Name = "CompanyName";
            CompanyName.ReadOnly = false;
            CompanyName.Size = new Size(249, 41);
            CompanyName.TabIndex = 34;
            CompanyName.TextAlignment = HorizontalAlignment.Left;
            CompanyName.UseSystemPasswordChar = false;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Gainsboro;
            panel1.Controls.Add(metroControlBox3);
            panel1.Controls.Add(metroControlBox2);
            panel1.Controls.Add(metroControlBox1);
            panel1.Controls.Add(label5);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(587, 34);
            panel1.TabIndex = 37;
            // 
            // metroControlBox3
            // 
            metroControlBox3.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            metroControlBox3.CloseHoverBackColor = Color.FromArgb(183, 40, 40);
            metroControlBox3.CloseHoverForeColor = Color.White;
            metroControlBox3.CloseNormalForeColor = Color.Gray;
            metroControlBox3.DefaultLocation = ReaLTaiizor.Enum.Metro.LocationType.Normal;
            metroControlBox3.DisabledForeColor = Color.DimGray;
            metroControlBox3.IsDerivedStyle = true;
            metroControlBox3.Location = new Point(475, 3);
            metroControlBox3.MaximizeBox = true;
            metroControlBox3.MaximizeHoverBackColor = Color.FromArgb(238, 238, 238);
            metroControlBox3.MaximizeHoverForeColor = Color.Gray;
            metroControlBox3.MaximizeNormalForeColor = Color.Gray;
            metroControlBox3.MinimizeBox = true;
            metroControlBox3.MinimizeHoverBackColor = Color.FromArgb(238, 238, 238);
            metroControlBox3.MinimizeHoverForeColor = Color.Gray;
            metroControlBox3.MinimizeNormalForeColor = Color.Gray;
            metroControlBox3.Name = "metroControlBox3";
            metroControlBox3.Size = new Size(100, 25);
            metroControlBox3.Style = ReaLTaiizor.Enum.Metro.Style.Light;
            metroControlBox3.StyleManager = null;
            metroControlBox3.TabIndex = 47;
            metroControlBox3.Text = "metroControlBox3";
            metroControlBox3.ThemeAuthor = "Taiizor";
            metroControlBox3.ThemeName = "MetroLight";
            // 
            // metroControlBox2
            // 
            metroControlBox2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            metroControlBox2.CloseHoverBackColor = Color.FromArgb(183, 40, 40);
            metroControlBox2.CloseHoverForeColor = Color.White;
            metroControlBox2.CloseNormalForeColor = Color.Gray;
            metroControlBox2.DefaultLocation = ReaLTaiizor.Enum.Metro.LocationType.Normal;
            metroControlBox2.DisabledForeColor = Color.DimGray;
            metroControlBox2.IsDerivedStyle = true;
            metroControlBox2.Location = new Point(657, 2);
            metroControlBox2.MaximizeBox = true;
            metroControlBox2.MaximizeHoverBackColor = Color.FromArgb(238, 238, 238);
            metroControlBox2.MaximizeHoverForeColor = Color.Gray;
            metroControlBox2.MaximizeNormalForeColor = Color.Gray;
            metroControlBox2.MinimizeBox = true;
            metroControlBox2.MinimizeHoverBackColor = Color.FromArgb(238, 238, 238);
            metroControlBox2.MinimizeHoverForeColor = Color.Gray;
            metroControlBox2.MinimizeNormalForeColor = Color.Gray;
            metroControlBox2.Name = "metroControlBox2";
            metroControlBox2.Size = new Size(100, 25);
            metroControlBox2.Style = ReaLTaiizor.Enum.Metro.Style.Light;
            metroControlBox2.StyleManager = null;
            metroControlBox2.TabIndex = 24;
            metroControlBox2.Text = "metroControlBox2";
            metroControlBox2.ThemeAuthor = "Taiizor";
            metroControlBox2.ThemeName = "MetroLight";
            // 
            // metroControlBox1
            // 
            metroControlBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            metroControlBox1.CloseHoverBackColor = Color.FromArgb(183, 40, 40);
            metroControlBox1.CloseHoverForeColor = Color.White;
            metroControlBox1.CloseNormalForeColor = Color.Gray;
            metroControlBox1.DefaultLocation = ReaLTaiizor.Enum.Metro.LocationType.Normal;
            metroControlBox1.DisabledForeColor = Color.DimGray;
            metroControlBox1.IsDerivedStyle = true;
            metroControlBox1.Location = new Point(832, 3);
            metroControlBox1.MaximizeBox = true;
            metroControlBox1.MaximizeHoverBackColor = Color.FromArgb(238, 238, 238);
            metroControlBox1.MaximizeHoverForeColor = Color.Gray;
            metroControlBox1.MaximizeNormalForeColor = Color.Gray;
            metroControlBox1.MinimizeBox = true;
            metroControlBox1.MinimizeHoverBackColor = Color.FromArgb(238, 238, 238);
            metroControlBox1.MinimizeHoverForeColor = Color.Gray;
            metroControlBox1.MinimizeNormalForeColor = Color.Gray;
            metroControlBox1.Name = "metroControlBox1";
            metroControlBox1.Size = new Size(100, 25);
            metroControlBox1.Style = ReaLTaiizor.Enum.Metro.Style.Light;
            metroControlBox1.StyleManager = null;
            metroControlBox1.TabIndex = 6;
            metroControlBox1.Text = "metroControlBox1";
            metroControlBox1.ThemeAuthor = "Taiizor";
            metroControlBox1.ThemeName = "MetroLight";
            // 
            // ContactName
            // 
            ContactName.BackColor = Color.Transparent;
            ContactName.Font = new Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point);
            ContactName.ForeColor = Color.DimGray;
            ContactName.Image = null;
            ContactName.Location = new Point(303, 122);
            ContactName.MaxLength = 32767;
            ContactName.Multiline = false;
            ContactName.Name = "ContactName";
            ContactName.ReadOnly = false;
            ContactName.Size = new Size(249, 41);
            ContactName.TabIndex = 47;
            ContactName.TextAlignment = HorizontalAlignment.Left;
            ContactName.UseSystemPasswordChar = false;
            // 
            // ContactTitle
            // 
            ContactTitle.BackColor = Color.Transparent;
            ContactTitle.Font = new Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point);
            ContactTitle.ForeColor = Color.DimGray;
            ContactTitle.Image = null;
            ContactTitle.Location = new Point(30, 191);
            ContactTitle.MaxLength = 32767;
            ContactTitle.Multiline = false;
            ContactTitle.Name = "ContactTitle";
            ContactTitle.ReadOnly = false;
            ContactTitle.Size = new Size(249, 41);
            ContactTitle.TabIndex = 48;
            ContactTitle.TextAlignment = HorizontalAlignment.Left;
            ContactTitle.UseSystemPasswordChar = false;
            // 
            // Address
            // 
            Address.BackColor = Color.Transparent;
            Address.Font = new Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point);
            Address.ForeColor = Color.DimGray;
            Address.Image = null;
            Address.Location = new Point(303, 191);
            Address.MaxLength = 32767;
            Address.Multiline = false;
            Address.Name = "Address";
            Address.ReadOnly = false;
            Address.Size = new Size(249, 41);
            Address.TabIndex = 49;
            Address.TextAlignment = HorizontalAlignment.Left;
            Address.UseSystemPasswordChar = false;
            // 
            // PostalCode
            // 
            PostalCode.BackColor = Color.Transparent;
            PostalCode.Font = new Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point);
            PostalCode.ForeColor = Color.DimGray;
            PostalCode.Image = null;
            PostalCode.Location = new Point(388, 264);
            PostalCode.MaxLength = 32767;
            PostalCode.Multiline = false;
            PostalCode.Name = "PostalCode";
            PostalCode.ReadOnly = false;
            PostalCode.Size = new Size(164, 41);
            PostalCode.TabIndex = 50;
            PostalCode.TextAlignment = HorizontalAlignment.Left;
            PostalCode.UseSystemPasswordChar = false;
            // 
            // Country
            // 
            Country.BackColor = Color.Transparent;
            Country.Font = new Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point);
            Country.ForeColor = Color.DimGray;
            Country.Image = null;
            Country.Location = new Point(30, 344);
            Country.MaxLength = 32767;
            Country.Multiline = false;
            Country.Name = "Country";
            Country.ReadOnly = false;
            Country.Size = new Size(249, 41);
            Country.TabIndex = 51;
            Country.TextAlignment = HorizontalAlignment.Left;
            Country.UseSystemPasswordChar = false;
            // 
            // Phone
            // 
            Phone.BackColor = Color.Transparent;
            Phone.Font = new Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point);
            Phone.ForeColor = Color.DimGray;
            Phone.Image = null;
            Phone.Location = new Point(303, 344);
            Phone.MaxLength = 32767;
            Phone.Multiline = false;
            Phone.Name = "Phone";
            Phone.ReadOnly = false;
            Phone.Size = new Size(249, 41);
            Phone.TabIndex = 52;
            Phone.TextAlignment = HorizontalAlignment.Left;
            Phone.UseSystemPasswordChar = false;
            // 
            // Fax
            // 
            Fax.BackColor = Color.Transparent;
            Fax.Font = new Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point);
            Fax.ForeColor = Color.DimGray;
            Fax.Image = null;
            Fax.Location = new Point(30, 410);
            Fax.MaxLength = 32767;
            Fax.Multiline = false;
            Fax.Name = "Fax";
            Fax.ReadOnly = false;
            Fax.Size = new Size(249, 41);
            Fax.TabIndex = 53;
            Fax.TextAlignment = HorizontalAlignment.Left;
            Fax.UseSystemPasswordChar = false;
            // 
            // HomePage
            // 
            HomePage.BackColor = Color.Transparent;
            HomePage.Font = new Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point);
            HomePage.ForeColor = Color.DimGray;
            HomePage.Image = null;
            HomePage.Location = new Point(303, 410);
            HomePage.MaxLength = 32767;
            HomePage.Multiline = false;
            HomePage.Name = "HomePage";
            HomePage.ReadOnly = false;
            HomePage.Size = new Size(249, 41);
            HomePage.TabIndex = 54;
            HomePage.TextAlignment = HorizontalAlignment.Left;
            HomePage.UseSystemPasswordChar = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(206, 246);
            label6.Name = "label6";
            label6.Size = new Size(44, 15);
            label6.TabIndex = 55;
            label6.Text = "Region";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(388, 246);
            label7.Name = "label7";
            label7.Size = new Size(70, 15);
            label7.TabIndex = 56;
            label7.Text = "Postal Code";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(304, 326);
            label8.Name = "label8";
            label8.Size = new Size(41, 15);
            label8.TabIndex = 57;
            label8.Text = "Phone";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(303, 392);
            label9.Name = "label9";
            label9.Size = new Size(69, 15);
            label9.TabIndex = 58;
            label9.Text = "Home Page";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(30, 392);
            label10.Name = "label10";
            label10.Size = new Size(25, 15);
            label10.TabIndex = 59;
            label10.Text = "Fax";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(304, 176);
            label11.Name = "label11";
            label11.Size = new Size(49, 15);
            label11.TabIndex = 60;
            label11.Text = "Address";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(304, 104);
            label12.Name = "label12";
            label12.Size = new Size(84, 15);
            label12.TabIndex = 61;
            label12.Text = "Contact Name";
            // 
            // AddSupplier
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(587, 522);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(HomePage);
            Controls.Add(Fax);
            Controls.Add(Phone);
            Controls.Add(Country);
            Controls.Add(PostalCode);
            Controls.Add(Address);
            Controls.Add(ContactTitle);
            Controls.Add(ContactName);
            Controls.Add(Region);
            Controls.Add(City);
            Controls.Add(selectSupplier);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(CategoryBtn);
            Controls.Add(label1);
            Controls.Add(CompanyName);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "AddSupplier";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "AddSupplier";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ReaLTaiizor.Controls.BigTextBox Region;
        private Label label5;
        private ReaLTaiizor.Controls.BigTextBox City;
        private Label selectSupplier;
        private Label label4;
        private Label label3;
        private Label label2;
        private ReaLTaiizor.Controls.HopeRoundButton CategoryBtn;
        private Label label1;
        private ReaLTaiizor.Controls.BigTextBox CompanyName;
        private Panel panel1;
        private ReaLTaiizor.Controls.MetroControlBox metroControlBox2;
        private ReaLTaiizor.Controls.MetroControlBox metroControlBox1;
        private ReaLTaiizor.Controls.MetroControlBox metroControlBox3;
        private ReaLTaiizor.Controls.BigTextBox ContactName;
        private ReaLTaiizor.Controls.BigTextBox ContactTitle;
        private ReaLTaiizor.Controls.BigTextBox Address;
        private ReaLTaiizor.Controls.BigTextBox PostalCode;
        private ReaLTaiizor.Controls.BigTextBox Country;
        private ReaLTaiizor.Controls.BigTextBox Phone;
        private ReaLTaiizor.Controls.BigTextBox Fax;
        private ReaLTaiizor.Controls.BigTextBox HomePage;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
    }
}