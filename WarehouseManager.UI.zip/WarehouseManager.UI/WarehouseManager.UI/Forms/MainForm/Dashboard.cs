﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WarehouseManager.UI.Forms.MainForm;
using WarehouseManager.UI.Forms.Categories;


namespace WarehouseManager.UI.Forms.MainForm
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();

        }

        private void viewcategories_Click(object sender, EventArgs e)
        {
            WarehouseManager warehouseManager = new WarehouseManager();
            warehouseManager.loadform(new Category());
        }

    }
}
