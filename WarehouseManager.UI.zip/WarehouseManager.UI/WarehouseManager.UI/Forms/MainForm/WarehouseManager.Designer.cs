﻿
namespace WarehouseManager.UI.Forms.MainForm
{
    partial class WarehouseManager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WarehouseManager));
            menuPanel = new Panel();
            label4 = new Label();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            metroControlBox1 = new ReaLTaiizor.Controls.MetroControlBox();
            panel7 = new Panel();
            button6 = new Button();
            panel3 = new Panel();
            SupplierBtn = new Button();
            panel6 = new Panel();
            productsBtn = new Button();
            panel4 = new Panel();
            CategoryButton = new Button();
            panel2 = new Panel();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            mainPanel = new Panel();
            menuPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel7.SuspendLayout();
            panel3.SuspendLayout();
            panel6.SuspendLayout();
            panel4.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // menuPanel
            // 
            menuPanel.BackColor = Color.WhiteSmoke;
            menuPanel.Controls.Add(label4);
            menuPanel.Controls.Add(label1);
            menuPanel.Controls.Add(pictureBox1);
            menuPanel.Controls.Add(pictureBox2);
            menuPanel.Controls.Add(metroControlBox1);
            menuPanel.Dock = DockStyle.Top;
            menuPanel.Location = new Point(0, 0);
            menuPanel.Name = "menuPanel";
            menuPanel.Size = new Size(836, 34);
            menuPanel.TabIndex = 0;
            menuPanel.Paint += menuPanel_Paint;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(221, 120);
            label4.Name = "label4";
            label4.Size = new Size(247, 15);
            label4.TabIndex = 12;
            label4.Text = "Welcome to our Warehouse manager system!";
            label4.Click += label1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(344, 9);
            label1.Name = "label1";
            label1.Size = new Size(247, 15);
            label1.TabIndex = 12;
            label1.Text = "Welcome to our Warehouse manager system!";
            label1.Click += label1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(8, 5);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(30, 24);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 12;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click_2;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.Transparent;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(89, 6);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(103, 22);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 1;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // metroControlBox1
            // 
            metroControlBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            metroControlBox1.CloseHoverBackColor = Color.FromArgb(183, 40, 40);
            metroControlBox1.CloseHoverForeColor = Color.White;
            metroControlBox1.CloseNormalForeColor = Color.Gray;
            metroControlBox1.DefaultLocation = ReaLTaiizor.Enum.Metro.LocationType.Normal;
            metroControlBox1.DisabledForeColor = Color.DimGray;
            metroControlBox1.IsDerivedStyle = true;
            metroControlBox1.Location = new Point(725, 3);
            metroControlBox1.MaximizeBox = true;
            metroControlBox1.MaximizeHoverBackColor = Color.FromArgb(238, 238, 238);
            metroControlBox1.MaximizeHoverForeColor = Color.Gray;
            metroControlBox1.MaximizeNormalForeColor = Color.Gray;
            metroControlBox1.MinimizeBox = true;
            metroControlBox1.MinimizeHoverBackColor = Color.FromArgb(238, 238, 238);
            metroControlBox1.MinimizeHoverForeColor = Color.Gray;
            metroControlBox1.MinimizeNormalForeColor = Color.Gray;
            metroControlBox1.Name = "metroControlBox1";
            metroControlBox1.Size = new Size(100, 25);
            metroControlBox1.Style = ReaLTaiizor.Enum.Metro.Style.Light;
            metroControlBox1.StyleManager = null;
            metroControlBox1.TabIndex = 1;
            metroControlBox1.Text = "metroControlBox1";
            metroControlBox1.ThemeAuthor = "Taiizor";
            metroControlBox1.ThemeName = "MetroLight";
            // 
            // panel7
            // 
            panel7.BackColor = SystemColors.ActiveCaption;
            panel7.Controls.Add(button6);
            panel7.Location = new Point(14, 127);
            panel7.Name = "panel7";
            panel7.Size = new Size(167, 43);
            panel7.TabIndex = 9;
            // 
            // button6
            // 
            button6.BackColor = SystemColors.MenuHighlight;
            button6.Cursor = Cursors.Hand;
            button6.Font = new Font("Roboto", 11F, FontStyle.Bold, GraphicsUnit.Point);
            button6.ForeColor = SystemColors.ButtonFace;
            button6.Image = (Image)resources.GetObject("button6.Image");
            button6.ImageAlign = ContentAlignment.MiddleLeft;
            button6.Location = new Point(-7, -10);
            button6.Name = "button6";
            button6.Padding = new Padding(17, 0, 0, 0);
            button6.Size = new Size(193, 62);
            button6.TabIndex = 5;
            button6.Text = "          Dashboard";
            button6.TextAlign = ContentAlignment.MiddleLeft;
            button6.UseVisualStyleBackColor = false;
            button6.Click += dashboardBtn_Click;
            // 
            // panel3
            // 
            panel3.BackColor = SystemColors.ActiveCaption;
            panel3.Controls.Add(SupplierBtn);
            panel3.Location = new Point(14, 176);
            panel3.Name = "panel3";
            panel3.Size = new Size(167, 43);
            panel3.TabIndex = 6;
            // 
            // SupplierBtn
            // 
            SupplierBtn.BackColor = SystemColors.MenuHighlight;
            SupplierBtn.Cursor = Cursors.Hand;
            SupplierBtn.Font = new Font("Roboto", 11F, FontStyle.Bold, GraphicsUnit.Point);
            SupplierBtn.ForeColor = SystemColors.ButtonFace;
            SupplierBtn.Image = (Image)resources.GetObject("SupplierBtn.Image");
            SupplierBtn.ImageAlign = ContentAlignment.MiddleLeft;
            SupplierBtn.Location = new Point(-6, -9);
            SupplierBtn.Name = "SupplierBtn";
            SupplierBtn.Padding = new Padding(17, 0, 0, 0);
            SupplierBtn.Size = new Size(192, 62);
            SupplierBtn.TabIndex = 5;
            SupplierBtn.Text = "          Supplier";
            SupplierBtn.TextAlign = ContentAlignment.MiddleLeft;
            SupplierBtn.UseVisualStyleBackColor = false;
            SupplierBtn.Click += SupplierBtn_Click;
            // 
            // panel6
            // 
            panel6.BackColor = SystemColors.ActiveCaption;
            panel6.Controls.Add(productsBtn);
            panel6.Location = new Point(14, 225);
            panel6.Name = "panel6";
            panel6.Size = new Size(167, 43);
            panel6.TabIndex = 9;
            // 
            // productsBtn
            // 
            productsBtn.BackColor = SystemColors.MenuHighlight;
            productsBtn.Cursor = Cursors.Hand;
            productsBtn.Font = new Font("Roboto", 11F, FontStyle.Bold, GraphicsUnit.Point);
            productsBtn.ForeColor = SystemColors.ButtonFace;
            productsBtn.Image = (Image)resources.GetObject("productsBtn.Image");
            productsBtn.ImageAlign = ContentAlignment.MiddleLeft;
            productsBtn.Location = new Point(-6, -10);
            productsBtn.Name = "productsBtn";
            productsBtn.Padding = new Padding(17, 0, 0, 0);
            productsBtn.Size = new Size(192, 62);
            productsBtn.TabIndex = 5;
            productsBtn.Text = "          Products";
            productsBtn.TextAlign = ContentAlignment.MiddleLeft;
            productsBtn.UseVisualStyleBackColor = false;
            productsBtn.Click += productsBtn_Click;
            // 
            // panel4
            // 
            panel4.BackColor = SystemColors.ActiveCaption;
            panel4.Controls.Add(CategoryButton);
            panel4.Location = new Point(14, 274);
            panel4.Name = "panel4";
            panel4.Size = new Size(167, 43);
            panel4.TabIndex = 7;
            // 
            // CategoryButton
            // 
            CategoryButton.BackColor = SystemColors.MenuHighlight;
            CategoryButton.Cursor = Cursors.Hand;
            CategoryButton.Font = new Font("Roboto", 11F, FontStyle.Bold, GraphicsUnit.Point);
            CategoryButton.ForeColor = SystemColors.ButtonFace;
            CategoryButton.Image = (Image)resources.GetObject("CategoryButton.Image");
            CategoryButton.ImageAlign = ContentAlignment.MiddleLeft;
            CategoryButton.Location = new Point(-6, -10);
            CategoryButton.Name = "CategoryButton";
            CategoryButton.Padding = new Padding(17, 0, 0, 0);
            CategoryButton.Size = new Size(184, 62);
            CategoryButton.TabIndex = 5;
            CategoryButton.Text = "          Category";
            CategoryButton.TextAlign = ContentAlignment.MiddleLeft;
            CategoryButton.UseVisualStyleBackColor = false;
            CategoryButton.Click += CategoryButton_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.DodgerBlue;
            panel2.Controls.Add(pictureBox4);
            panel2.Controls.Add(panel7);
            panel2.Controls.Add(panel4);
            panel2.Controls.Add(panel3);
            panel2.Controls.Add(panel6);
            panel2.Controls.Add(pictureBox3);
            panel2.Dock = DockStyle.Left;
            panel2.Location = new Point(0, 34);
            panel2.Name = "panel2";
            panel2.Size = new Size(192, 416);
            panel2.TabIndex = 11;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(62, 37);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(66, 60);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 14;
            pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(-46, 252);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(172, 187);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 13;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // mainPanel
            // 
            mainPanel.BackColor = Color.White;
            mainPanel.Cursor = Cursors.Hand;
            mainPanel.Dock = DockStyle.Right;
            mainPanel.Location = new Point(187, 34);
            mainPanel.Name = "mainPanel";
            mainPanel.Size = new Size(649, 416);
            mainPanel.TabIndex = 12;
            mainPanel.Paint += mainPanel_Paint;
            // 
            // WarehouseManager
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(836, 450);
            Controls.Add(mainPanel);
            Controls.Add(panel2);
            Controls.Add(menuPanel);
            FormBorderStyle = FormBorderStyle.None;
            Name = "WarehouseManager";
            Text = "WarehouseManager";
            Load += WarehouseManager_Load;
            menuPanel.ResumeLayout(false);
            menuPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel7.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel6.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel menuPanel;
        private PictureBox pictureBox2;
        private ReaLTaiizor.Controls.MetroControlBox metroControlBox1;
        private Panel panel3;
        private Button SupplierBtn;
        private Panel panel4;
        private Button CategoryButton;
        private Panel panel6;
        private Button productsBtn;
        private Panel panel7;
        private Button button6;
        private Panel panel2;
        private PictureBox pictureBox1;
        private Label label1;
        private PictureBox pictureBox3;
        private Panel mainPanel;
        private PictureBox pictureBox4;
        private Label label4;
    }

}