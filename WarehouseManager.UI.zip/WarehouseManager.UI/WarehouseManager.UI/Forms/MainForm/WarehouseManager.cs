﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WarehouseManager.UI.Forms.Suppliers;
using WarehouseManager.UI.Forms.Categories;
using WarehouseManager.UI.Forms.Products;
using WarehouseManager.Data;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Data.SqlClient;

namespace WarehouseManager.UI.Forms.MainForm
{
    public partial class WarehouseManager : Form
    {
        private bool isDragging = false;
        private Point lastCursor;
        private Point lastForm;
        public WarehouseManager()
        {
            InitializeComponent();

            this.StartPosition = FormStartPosition.CenterScreen;

            loadform(new Dashboard());


        }
        public void loadform(object Form)
        {

            if (this.mainPanel.Controls.Count > 0)
                this.mainPanel.Controls.RemoveAt(0);
            Form? f = Form as Form;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;
            this.mainPanel.Controls.Add(f);
            this.mainPanel.Tag = f;
            f.Show();

        }
        private void WarehouseManager_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void menuPanel_Paint(object sender, PaintEventArgs e)
        {

        }
        // Handle MouseDown event
        private void WarehouseManager_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = true;
                lastCursor = Cursor.Position;
                lastForm = Location;
            }
        }

        // Handle MouseMove event
        private void WarehouseManager_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                int deltaX = Cursor.Position.X - lastCursor.X;
                int deltaY = Cursor.Position.Y - lastCursor.Y;
                Location = new Point(lastForm.X + deltaX, lastForm.Y + deltaY);
            }
        }

        // Handle MouseUp event
        private void WarehouseManager_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = false;
            }
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void hopePictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void SupplierBtn_Click(object sender, EventArgs e)
        {
            loadform(new Supplier());
        }

        private void Suppliersbtn_Click(object sender, EventArgs e)
        {
            // loadform(new Supplier());
        }

        private void CategoryButton_Click(object sender, EventArgs e)
        {
            loadform(new Category());
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dashboardBtn_Click(object sender, EventArgs e)
        {
            loadform(new Dashboard());
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_2(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void mainPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void productsBtn_Click(object sender, EventArgs e)
        {
            loadform(new Product());
        }

        private void connection_Click(object sender, EventArgs e)
        {

            try
            {

                using IDbConnection db = new SqlConnection(Extensions.connectionString);
                if (db.State == ConnectionState.Closed)
                    db.Open();
                MessageBox.Show("connected");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
