﻿namespace WarehouseManager.UI.Forms.MainForm
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            label3 = new Label();
            label2 = new Label();
            poisonDataGridView1 = new ReaLTaiizor.Controls.PoisonDataGridView();
            ProductName = new DataGridViewTextBoxColumn();
            QuantityPerUnit = new DataGridViewTextBoxColumn();
            UnitPrice = new DataGridViewTextBoxColumn();
            UnitsInStock = new DataGridViewTextBoxColumn();
            UnitsOnOrder = new DataGridViewTextBoxColumn();
            ReorderLevel = new DataGridViewTextBoxColumn();
            Discontinued = new DataGridViewTextBoxColumn();
            dashboardBtn = new ReaLTaiizor.Controls.HopeButton();
            dungeonButtonLeft3 = new ReaLTaiizor.Controls.DungeonButtonLeft();
            viewcategories = new ReaLTaiizor.Controls.DungeonButtonLeft();
            hopeButton1 = new ReaLTaiizor.Controls.HopeButton();
            dungeonButtonLeft1 = new ReaLTaiizor.Controls.DungeonButtonLeft();
            ((System.ComponentModel.ISupportInitialize)poisonDataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(41, 295);
            label3.Name = "label3";
            label3.Size = new Size(101, 15);
            label3.TabIndex = 25;
            label3.Text = "Popular  Products";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(38, 18);
            label2.Name = "label2";
            label2.Size = new Size(64, 15);
            label2.TabIndex = 24;
            label2.Text = "Dashboard";
            // 
            // poisonDataGridView1
            // 
            poisonDataGridView1.AllowUserToResizeRows = false;
            poisonDataGridView1.BackgroundColor = Color.WhiteSmoke;
            poisonDataGridView1.BorderStyle = BorderStyle.None;
            poisonDataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.None;
            poisonDataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(0, 174, 219);
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = Color.FromArgb(255, 255, 255);
            dataGridViewCellStyle1.SelectionBackColor = Color.FromArgb(0, 198, 247);
            dataGridViewCellStyle1.SelectionForeColor = Color.FromArgb(17, 17, 17);
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            poisonDataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            poisonDataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            poisonDataGridView1.Columns.AddRange(new DataGridViewColumn[] { ProductName, QuantityPerUnit, UnitPrice, UnitsInStock, UnitsOnOrder, ReorderLevel, Discontinued });
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(255, 255, 255);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = Color.FromArgb(136, 136, 136);
            dataGridViewCellStyle2.SelectionBackColor = Color.FromArgb(0, 198, 247);
            dataGridViewCellStyle2.SelectionForeColor = Color.FromArgb(17, 17, 17);
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            poisonDataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            poisonDataGridView1.EnableHeadersVisualStyles = false;
            poisonDataGridView1.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            poisonDataGridView1.GridColor = Color.FromArgb(255, 255, 255);
            poisonDataGridView1.Location = new Point(41, 315);
            poisonDataGridView1.Name = "poisonDataGridView1";
            poisonDataGridView1.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.FromArgb(0, 174, 219);
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(255, 255, 255);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(0, 198, 247);
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(17, 17, 17);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            poisonDataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            poisonDataGridView1.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            poisonDataGridView1.RowTemplate.Height = 25;
            poisonDataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            poisonDataGridView1.Size = new Size(586, 84);
            poisonDataGridView1.TabIndex = 23;
            // 
            // ProductName
            // 
            ProductName.HeaderText = "ProductName";
            ProductName.Name = "ProductName";
            // 
            // QuantityPerUnit
            // 
            QuantityPerUnit.HeaderText = "QuantityPerUnit";
            QuantityPerUnit.Name = "QuantityPerUnit";
            // 
            // UnitPrice
            // 
            UnitPrice.HeaderText = "UnitPrice";
            UnitPrice.Name = "UnitPrice";
            // 
            // UnitsInStock
            // 
            UnitsInStock.HeaderText = "UnitsInStock";
            UnitsInStock.Name = "UnitsInStock";
            // 
            // UnitsOnOrder
            // 
            UnitsOnOrder.HeaderText = "UnitsOnOrder";
            UnitsOnOrder.Name = "UnitsOnOrder";
            // 
            // ReorderLevel
            // 
            ReorderLevel.HeaderText = "ReorderLevel";
            ReorderLevel.Name = "ReorderLevel";
            // 
            // Discontinued
            // 
            Discontinued.HeaderText = "Discontinued";
            Discontinued.Name = "Discontinued";
            // 
            // dashboardBtn
            // 
            dashboardBtn.BorderColor = Color.FromArgb(220, 223, 230);
            dashboardBtn.ButtonType = ReaLTaiizor.Util.HopeButtonType.Primary;
            dashboardBtn.DangerColor = Color.FromArgb(245, 108, 108);
            dashboardBtn.DefaultColor = Color.FromArgb(255, 255, 255);
            dashboardBtn.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dashboardBtn.HoverTextColor = Color.FromArgb(48, 49, 51);
            dashboardBtn.InfoColor = Color.FromArgb(144, 147, 153);
            dashboardBtn.Location = new Point(341, 160);
            dashboardBtn.Name = "dashboardBtn";
            dashboardBtn.PrimaryColor = Color.DarkTurquoise;
            dashboardBtn.Size = new Size(286, 123);
            dashboardBtn.SuccessColor = Color.FromArgb(103, 194, 58);
            dashboardBtn.TabIndex = 22;
            dashboardBtn.Text = "Display all suppliers, add new, edit and delete";
            dashboardBtn.TextColor = Color.White;
            dashboardBtn.WarningColor = Color.FromArgb(230, 162, 60);
            // 
            // dungeonButtonLeft3
            // 
            dungeonButtonLeft3.BackColor = Color.Transparent;
            dungeonButtonLeft3.BorderColor = Color.FromArgb(180, 180, 180);
            dungeonButtonLeft3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dungeonButtonLeft3.Image = null;
            dungeonButtonLeft3.ImageAlign = ContentAlignment.MiddleLeft;
            dungeonButtonLeft3.InactiveColorA = Color.FromArgb(253, 252, 252);
            dungeonButtonLeft3.InactiveColorB = Color.FromArgb(239, 237, 236);
            dungeonButtonLeft3.Location = new Point(450, 43);
            dungeonButtonLeft3.Name = "dungeonButtonLeft3";
            dungeonButtonLeft3.PressedColorA = Color.FromArgb(226, 226, 226);
            dungeonButtonLeft3.PressedColorB = Color.FromArgb(237, 237, 237);
            dungeonButtonLeft3.PressedContourColorA = Color.FromArgb(167, 167, 167);
            dungeonButtonLeft3.PressedContourColorB = Color.FromArgb(167, 167, 167);
            dungeonButtonLeft3.Size = new Size(177, 100);
            dungeonButtonLeft3.TabIndex = 21;
            dungeonButtonLeft3.Text = "View Suppliers";
            dungeonButtonLeft3.TextAlignment = StringAlignment.Center;
            // 
            // viewcategories
            // 
            viewcategories.BackColor = Color.Transparent;
            viewcategories.BorderColor = Color.FromArgb(180, 180, 180);
            viewcategories.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            viewcategories.Image = null;
            viewcategories.ImageAlign = ContentAlignment.MiddleLeft;
            viewcategories.InactiveColorA = Color.FromArgb(253, 252, 252);
            viewcategories.InactiveColorB = Color.FromArgb(239, 237, 236);
            viewcategories.Location = new Point(245, 43);
            viewcategories.Name = "viewcategories";
            viewcategories.PressedColorA = Color.FromArgb(226, 226, 226);
            viewcategories.PressedColorB = Color.FromArgb(237, 237, 237);
            viewcategories.PressedContourColorA = Color.FromArgb(167, 167, 167);
            viewcategories.PressedContourColorB = Color.FromArgb(167, 167, 167);
            viewcategories.Size = new Size(177, 100);
            viewcategories.TabIndex = 20;
            viewcategories.Text = "View Categories";
            viewcategories.TextAlignment = StringAlignment.Center;
            viewcategories.Click += viewcategories_Click;
            // 
            // hopeButton1
            // 
            hopeButton1.BorderColor = Color.FromArgb(220, 223, 230);
            hopeButton1.ButtonType = ReaLTaiizor.Util.HopeButtonType.Primary;
            hopeButton1.DangerColor = Color.FromArgb(245, 108, 108);
            hopeButton1.DefaultColor = Color.FromArgb(255, 255, 255);
            hopeButton1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            hopeButton1.HoverTextColor = Color.FromArgb(48, 49, 51);
            hopeButton1.InfoColor = Color.FromArgb(144, 147, 153);
            hopeButton1.Location = new Point(41, 160);
            hopeButton1.Name = "hopeButton1";
            hopeButton1.PrimaryColor = Color.SteelBlue;
            hopeButton1.Size = new Size(282, 123);
            hopeButton1.SuccessColor = Color.FromArgb(103, 194, 58);
            hopeButton1.TabIndex = 19;
            hopeButton1.Text = "Display all products, add new, edit and delete";
            hopeButton1.TextColor = Color.White;
            hopeButton1.WarningColor = Color.FromArgb(230, 162, 60);
            // 
            // dungeonButtonLeft1
            // 
            dungeonButtonLeft1.BackColor = Color.Transparent;
            dungeonButtonLeft1.BorderColor = Color.FromArgb(180, 180, 180);
            dungeonButtonLeft1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dungeonButtonLeft1.Image = null;
            dungeonButtonLeft1.ImageAlign = ContentAlignment.MiddleLeft;
            dungeonButtonLeft1.InactiveColorA = Color.FromArgb(253, 252, 252);
            dungeonButtonLeft1.InactiveColorB = Color.FromArgb(239, 237, 236);
            dungeonButtonLeft1.Location = new Point(41, 43);
            dungeonButtonLeft1.Name = "dungeonButtonLeft1";
            dungeonButtonLeft1.PressedColorA = Color.FromArgb(226, 226, 226);
            dungeonButtonLeft1.PressedColorB = Color.FromArgb(237, 237, 237);
            dungeonButtonLeft1.PressedContourColorA = Color.FromArgb(167, 167, 167);
            dungeonButtonLeft1.PressedContourColorB = Color.FromArgb(167, 167, 167);
            dungeonButtonLeft1.Size = new Size(177, 100);
            dungeonButtonLeft1.TabIndex = 18;
            dungeonButtonLeft1.Text = "View products";
            dungeonButtonLeft1.TextAlignment = StringAlignment.Center;
            // 
            // Dashboard
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(671, 416);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(poisonDataGridView1);
            Controls.Add(dashboardBtn);
            Controls.Add(dungeonButtonLeft3);
            Controls.Add(viewcategories);
            Controls.Add(hopeButton1);
            Controls.Add(dungeonButtonLeft1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Dashboard";
            Text = "Dashboard";
            ((System.ComponentModel.ISupportInitialize)poisonDataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label3;
        private Label label2;
        private ReaLTaiizor.Controls.PoisonDataGridView poisonDataGridView1;
        private ReaLTaiizor.Controls.HopeButton dashboardBtn;
        private ReaLTaiizor.Controls.DungeonButtonLeft dungeonButtonLeft3;
        private ReaLTaiizor.Controls.DungeonButtonLeft viewcategories;
        private ReaLTaiizor.Controls.HopeButton hopeButton1;
        private ReaLTaiizor.Controls.DungeonButtonLeft dungeonButtonLeft1;
        private DataGridViewTextBoxColumn ProductName;
        private DataGridViewTextBoxColumn QuantityPerUnit;
        private DataGridViewTextBoxColumn UnitPrice;
        private DataGridViewTextBoxColumn UnitsInStock;
        private DataGridViewTextBoxColumn UnitsOnOrder;
        private DataGridViewTextBoxColumn ReorderLevel;
        private DataGridViewTextBoxColumn Discontinued;
    }
}