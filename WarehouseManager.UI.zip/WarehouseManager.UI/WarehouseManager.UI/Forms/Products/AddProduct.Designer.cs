﻿namespace WarehouseManager.UI.Forms.Products
{
    partial class AddProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            CategoryBtn = new ReaLTaiizor.Controls.HopeRoundButton();
            label1 = new Label();
            productName = new ReaLTaiizor.Controls.BigTextBox();
            panel1 = new Panel();
            metroControlBox2 = new ReaLTaiizor.Controls.MetroControlBox();
            metroControlBox1 = new ReaLTaiizor.Controls.MetroControlBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            selectSupplier = new Label();
            QuantityPerUnit = new ReaLTaiizor.Controls.BigTextBox();
            Supplier = new ReaLTaiizor.Controls.AloneComboBox();
            Category = new ReaLTaiizor.Controls.AloneComboBox();
            label5 = new Label();
            UnitPrice = new ReaLTaiizor.Controls.BigTextBox();
            label6 = new Label();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // CategoryBtn
            // 
            CategoryBtn.BorderColor = Color.FromArgb(220, 223, 230);
            CategoryBtn.ButtonType = ReaLTaiizor.Util.HopeButtonType.Primary;
            CategoryBtn.DangerColor = Color.FromArgb(245, 108, 108);
            CategoryBtn.DefaultColor = Color.FromArgb(255, 255, 255);
            CategoryBtn.Font = new Font("Segoe UI Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            CategoryBtn.HoverTextColor = Color.FromArgb(48, 49, 51);
            CategoryBtn.InfoColor = Color.FromArgb(144, 147, 153);
            CategoryBtn.Location = new Point(228, 395);
            CategoryBtn.Name = "CategoryBtn";
            CategoryBtn.PrimaryColor = Color.Green;
            CategoryBtn.Size = new Size(122, 32);
            CategoryBtn.SuccessColor = Color.FromArgb(103, 194, 58);
            CategoryBtn.TabIndex = 22;
            CategoryBtn.Text = "Submit";
            CategoryBtn.TextColor = Color.White;
            CategoryBtn.WarningColor = Color.FromArgb(230, 162, 60);
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 17.25F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(117, 50);
            label1.Name = "label1";
            label1.Size = new Size(145, 31);
            label1.TabIndex = 20;
            label1.Text = "Add Product";
            // 
            // productName
            // 
            productName.BackColor = Color.Transparent;
            productName.Font = new Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point);
            productName.ForeColor = Color.DimGray;
            productName.Image = null;
            productName.Location = new Point(24, 124);
            productName.MaxLength = 32767;
            productName.Multiline = false;
            productName.Name = "productName";
            productName.ReadOnly = false;
            productName.Size = new Size(326, 41);
            productName.TabIndex = 18;
            productName.TextAlignment = HorizontalAlignment.Left;
            productName.UseSystemPasswordChar = false;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Gainsboro;
            panel1.Controls.Add(label6);
            panel1.Controls.Add(metroControlBox2);
            panel1.Controls.Add(metroControlBox1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(382, 34);
            panel1.TabIndex = 23;
            // 
            // metroControlBox2
            // 
            metroControlBox2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            metroControlBox2.CloseHoverBackColor = Color.FromArgb(183, 40, 40);
            metroControlBox2.CloseHoverForeColor = Color.White;
            metroControlBox2.CloseNormalForeColor = Color.Gray;
            metroControlBox2.DefaultLocation = ReaLTaiizor.Enum.Metro.LocationType.Normal;
            metroControlBox2.DisabledForeColor = Color.DimGray;
            metroControlBox2.IsDerivedStyle = true;
            metroControlBox2.Location = new Point(270, 2);
            metroControlBox2.MaximizeBox = true;
            metroControlBox2.MaximizeHoverBackColor = Color.FromArgb(238, 238, 238);
            metroControlBox2.MaximizeHoverForeColor = Color.Gray;
            metroControlBox2.MaximizeNormalForeColor = Color.Gray;
            metroControlBox2.MinimizeBox = true;
            metroControlBox2.MinimizeHoverBackColor = Color.FromArgb(238, 238, 238);
            metroControlBox2.MinimizeHoverForeColor = Color.Gray;
            metroControlBox2.MinimizeNormalForeColor = Color.Gray;
            metroControlBox2.Name = "metroControlBox2";
            metroControlBox2.Size = new Size(100, 25);
            metroControlBox2.Style = ReaLTaiizor.Enum.Metro.Style.Light;
            metroControlBox2.StyleManager = null;
            metroControlBox2.TabIndex = 24;
            metroControlBox2.Text = "metroControlBox2";
            metroControlBox2.ThemeAuthor = "Taiizor";
            metroControlBox2.ThemeName = "MetroLight";
            // 
            // metroControlBox1
            // 
            metroControlBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            metroControlBox1.CloseHoverBackColor = Color.FromArgb(183, 40, 40);
            metroControlBox1.CloseHoverForeColor = Color.White;
            metroControlBox1.CloseNormalForeColor = Color.Gray;
            metroControlBox1.DefaultLocation = ReaLTaiizor.Enum.Metro.LocationType.Normal;
            metroControlBox1.DisabledForeColor = Color.DimGray;
            metroControlBox1.IsDerivedStyle = true;
            metroControlBox1.Location = new Point(445, 3);
            metroControlBox1.MaximizeBox = true;
            metroControlBox1.MaximizeHoverBackColor = Color.FromArgb(238, 238, 238);
            metroControlBox1.MaximizeHoverForeColor = Color.Gray;
            metroControlBox1.MaximizeNormalForeColor = Color.Gray;
            metroControlBox1.MinimizeBox = true;
            metroControlBox1.MinimizeHoverBackColor = Color.FromArgb(238, 238, 238);
            metroControlBox1.MinimizeHoverForeColor = Color.Gray;
            metroControlBox1.MinimizeNormalForeColor = Color.Gray;
            metroControlBox1.Name = "metroControlBox1";
            metroControlBox1.Size = new Size(100, 25);
            metroControlBox1.Style = ReaLTaiizor.Enum.Metro.Style.Light;
            metroControlBox1.StyleManager = null;
            metroControlBox1.TabIndex = 6;
            metroControlBox1.Text = "metroControlBox1";
            metroControlBox1.ThemeAuthor = "Taiizor";
            metroControlBox1.ThemeName = "MetroLight";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(24, 106);
            label2.Name = "label2";
            label2.Size = new Size(82, 15);
            label2.TabIndex = 24;
            label2.Text = "Product name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(24, 301);
            label3.Name = "label3";
            label3.Size = new Size(98, 15);
            label3.TabIndex = 25;
            label3.Text = "Quantity Per Unit";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(24, 237);
            label4.Name = "label4";
            label4.Size = new Size(134, 15);
            label4.TabIndex = 26;
            label4.Text = "Select Product Category";
            // 
            // selectSupplier
            // 
            selectSupplier.AutoSize = true;
            selectSupplier.Location = new Point(24, 178);
            selectSupplier.Name = "selectSupplier";
            selectSupplier.Size = new Size(84, 15);
            selectSupplier.TabIndex = 27;
            selectSupplier.Text = "Select Supplier";
            // 
            // QuantityPerUnit
            // 
            QuantityPerUnit.BackColor = Color.Transparent;
            QuantityPerUnit.Font = new Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point);
            QuantityPerUnit.ForeColor = Color.DimGray;
            QuantityPerUnit.Image = null;
            QuantityPerUnit.Location = new Point(24, 334);
            QuantityPerUnit.MaxLength = 32767;
            QuantityPerUnit.Multiline = false;
            QuantityPerUnit.Name = "QuantityPerUnit";
            QuantityPerUnit.ReadOnly = false;
            QuantityPerUnit.Size = new Size(150, 41);
            QuantityPerUnit.TabIndex = 29;
            QuantityPerUnit.TextAlignment = HorizontalAlignment.Left;
            QuantityPerUnit.UseSystemPasswordChar = false;
            // 
            // Supplier
            // 
            Supplier.DrawMode = DrawMode.OwnerDrawFixed;
            Supplier.DropDownStyle = ComboBoxStyle.DropDownList;
            Supplier.EnabledCalc = true;
            Supplier.FormattingEnabled = true;
            Supplier.ItemHeight = 20;
            Supplier.Location = new Point(24, 196);
            Supplier.Name = "Supplier";
            Supplier.Size = new Size(326, 26);
            Supplier.TabIndex = 30;
            // 
            // Category
            // 
            Category.DrawMode = DrawMode.OwnerDrawFixed;
            Category.DropDownStyle = ComboBoxStyle.DropDownList;
            Category.EnabledCalc = true;
            Category.FormattingEnabled = true;
            Category.ItemHeight = 20;
            Category.Location = new Point(24, 255);
            Category.Name = "Category";
            Category.Size = new Size(326, 26);
            Category.TabIndex = 31;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(195, 301);
            label5.Name = "label5";
            label5.Size = new Size(58, 15);
            label5.TabIndex = 32;
            label5.Text = "Unit Price";
            // 
            // UnitPrice
            // 
            UnitPrice.BackColor = Color.Transparent;
            UnitPrice.Font = new Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point);
            UnitPrice.ForeColor = Color.DimGray;
            UnitPrice.Image = null;
            UnitPrice.Location = new Point(195, 334);
            UnitPrice.MaxLength = 32767;
            UnitPrice.Multiline = false;
            UnitPrice.Name = "UnitPrice";
            UnitPrice.ReadOnly = false;
            UnitPrice.Size = new Size(155, 41);
            UnitPrice.TabIndex = 33;
            UnitPrice.TextAlignment = HorizontalAlignment.Left;
            UnitPrice.UseSystemPasswordChar = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(12, 9);
            label6.Name = "label6";
            label6.Size = new Size(49, 15);
            label6.TabIndex = 34;
            label6.Text = "Product";
            // 
            // AddProduct
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(382, 462);
            Controls.Add(UnitPrice);
            Controls.Add(label5);
            Controls.Add(Category);
            Controls.Add(Supplier);
            Controls.Add(QuantityPerUnit);
            Controls.Add(selectSupplier);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(CategoryBtn);
            Controls.Add(label1);
            Controls.Add(productName);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "AddProduct";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "AddProduct";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ReaLTaiizor.Controls.HopeRoundButton CategoryBtn;
        private Label label1;
        private ReaLTaiizor.Controls.BigTextBox productName;
        private Panel panel1;
        private ReaLTaiizor.Controls.MetroControlBox metroControlBox1;
        private ReaLTaiizor.Controls.MetroControlBox metroControlBox2;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label selectSupplier;
        private ReaLTaiizor.Controls.BigTextBox QuantityPerUnit;
        private ReaLTaiizor.Controls.AloneComboBox Supplier;
        private ReaLTaiizor.Controls.AloneComboBox Category;
        private Label label5;
        private ReaLTaiizor.Controls.BigTextBox UnitPrice;
        private Label label6;
    }
}