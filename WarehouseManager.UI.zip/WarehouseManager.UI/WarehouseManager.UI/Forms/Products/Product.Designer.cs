﻿namespace WarehouseManager.UI.Forms.Products
{
    partial class Product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Product));
            backButton = new Label();
            bigLabel1 = new ReaLTaiizor.Controls.BigLabel();
            DeleteCategory = new ReaLTaiizor.Controls.HopeRoundButton();
            AditProduct = new ReaLTaiizor.Controls.HopeRoundButton();
            AddProduct = new ReaLTaiizor.Controls.HopeRoundButton();
            poisonDataGridView1 = new ReaLTaiizor.Controls.PoisonDataGridView();
            ProductID = new DataGridViewTextBoxColumn();
            ProductName = new DataGridViewTextBoxColumn();
            Supplier = new DataGridViewTextBoxColumn();
            Category = new DataGridViewTextBoxColumn();
            QuantityPerUnit = new DataGridViewTextBoxColumn();
            UnitPrice = new DataGridViewTextBoxColumn();
            UnitsInStock = new DataGridViewTextBoxColumn();
            UnitsOnOrder = new DataGridViewTextBoxColumn();
            ReorderLevel = new DataGridViewTextBoxColumn();
            Discontinued = new DataGridViewTextBoxColumn();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            label2 = new Label();
            smallTextBox1 = new ReaLTaiizor.Controls.SmallTextBox();
            ((System.ComponentModel.ISupportInitialize)poisonDataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // backButton
            // 
            backButton.AutoSize = true;
            backButton.Cursor = Cursors.Hand;
            backButton.Location = new Point(12, 13);
            backButton.Name = "backButton";
            backButton.Size = new Size(32, 15);
            backButton.TabIndex = 23;
            backButton.Text = "back";
            // 
            // bigLabel1
            // 
            bigLabel1.AutoSize = true;
            bigLabel1.BackColor = Color.Transparent;
            bigLabel1.Font = new Font("Segoe UI Semibold", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            bigLabel1.ForeColor = Color.FromArgb(80, 80, 80);
            bigLabel1.Location = new Point(5, 88);
            bigLabel1.Name = "bigLabel1";
            bigLabel1.Size = new Size(126, 37);
            bigLabel1.TabIndex = 22;
            bigLabel1.Text = "Products";
            // 
            // DeleteCategory
            // 
            DeleteCategory.BorderColor = Color.FromArgb(220, 223, 230);
            DeleteCategory.ButtonType = ReaLTaiizor.Util.HopeButtonType.Primary;
            DeleteCategory.DangerColor = Color.FromArgb(245, 108, 108);
            DeleteCategory.DefaultColor = Color.FromArgb(255, 255, 255);
            DeleteCategory.Font = new Font("Segoe UI Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            DeleteCategory.HoverTextColor = Color.FromArgb(48, 49, 51);
            DeleteCategory.InfoColor = Color.FromArgb(144, 147, 153);
            DeleteCategory.Location = new Point(510, 100);
            DeleteCategory.Name = "DeleteCategory";
            DeleteCategory.PrimaryColor = Color.FromArgb(192, 0, 0);
            DeleteCategory.Size = new Size(122, 32);
            DeleteCategory.SuccessColor = Color.FromArgb(103, 194, 58);
            DeleteCategory.TabIndex = 21;
            DeleteCategory.Text = "Delete Product";
            DeleteCategory.TextColor = Color.White;
            DeleteCategory.WarningColor = Color.FromArgb(230, 162, 60);
            // 
            // AditProduct
            // 
            AditProduct.BorderColor = Color.FromArgb(220, 223, 230);
            AditProduct.ButtonType = ReaLTaiizor.Util.HopeButtonType.Primary;
            AditProduct.DangerColor = Color.FromArgb(245, 108, 108);
            AditProduct.DefaultColor = Color.FromArgb(255, 255, 255);
            AditProduct.Font = new Font("Segoe UI Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            AditProduct.HoverTextColor = Color.FromArgb(48, 49, 51);
            AditProduct.InfoColor = Color.FromArgb(144, 147, 153);
            AditProduct.Location = new Point(368, 100);
            AditProduct.Name = "AditProduct";
            AditProduct.PrimaryColor = Color.FromArgb(255, 128, 0);
            AditProduct.Size = new Size(122, 32);
            AditProduct.SuccessColor = Color.FromArgb(103, 194, 58);
            AditProduct.TabIndex = 20;
            AditProduct.Text = "Edit Product";
            AditProduct.TextColor = Color.White;
            AditProduct.WarningColor = Color.FromArgb(230, 162, 60);
            // 
            // AddProduct
            // 
            AddProduct.BorderColor = Color.FromArgb(220, 223, 230);
            AddProduct.ButtonType = ReaLTaiizor.Util.HopeButtonType.Primary;
            AddProduct.DangerColor = Color.FromArgb(245, 108, 108);
            AddProduct.DefaultColor = Color.FromArgb(255, 255, 255);
            AddProduct.Font = new Font("Segoe UI Semibold", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            AddProduct.HoverTextColor = Color.FromArgb(48, 49, 51);
            AddProduct.InfoColor = Color.FromArgb(144, 147, 153);
            AddProduct.Location = new Point(226, 100);
            AddProduct.Name = "AddProduct";
            AddProduct.PrimaryColor = Color.FromArgb(0, 192, 0);
            AddProduct.Size = new Size(122, 32);
            AddProduct.SuccessColor = Color.FromArgb(103, 194, 58);
            AddProduct.TabIndex = 19;
            AddProduct.Text = "Add Product";
            AddProduct.TextColor = Color.White;
            AddProduct.WarningColor = Color.FromArgb(230, 162, 60);
            AddProduct.Click += AddProduct_Click;
            // 
            // poisonDataGridView1
            // 
            poisonDataGridView1.AllowUserToResizeRows = false;
            poisonDataGridView1.BackgroundColor = Color.FromArgb(224, 224, 224);
            poisonDataGridView1.BorderStyle = BorderStyle.None;
            poisonDataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.None;
            poisonDataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(0, 174, 219);
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = Color.FromArgb(255, 255, 255);
            dataGridViewCellStyle1.SelectionBackColor = Color.FromArgb(0, 198, 247);
            dataGridViewCellStyle1.SelectionForeColor = Color.FromArgb(17, 17, 17);
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            poisonDataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            poisonDataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            poisonDataGridView1.Columns.AddRange(new DataGridViewColumn[] { ProductID, ProductName, Supplier, Category, QuantityPerUnit, UnitPrice, UnitsInStock, UnitsOnOrder, ReorderLevel, Discontinued });
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(255, 255, 255);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = Color.FromArgb(136, 136, 136);
            dataGridViewCellStyle2.SelectionBackColor = Color.FromArgb(0, 198, 247);
            dataGridViewCellStyle2.SelectionForeColor = Color.FromArgb(17, 17, 17);
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            poisonDataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            poisonDataGridView1.EnableHeadersVisualStyles = false;
            poisonDataGridView1.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            poisonDataGridView1.GridColor = Color.FromArgb(255, 255, 255);
            poisonDataGridView1.Location = new Point(12, 156);
            poisonDataGridView1.Name = "poisonDataGridView1";
            poisonDataGridView1.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.FromArgb(0, 174, 219);
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(255, 255, 255);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(0, 198, 247);
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(17, 17, 17);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            poisonDataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            poisonDataGridView1.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            poisonDataGridView1.RowTemplate.Height = 25;
            poisonDataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            poisonDataGridView1.Size = new Size(625, 209);
            poisonDataGridView1.TabIndex = 18;
            // 
            // ProductID
            // 
            ProductID.HeaderText = "ProductID";
            ProductID.Name = "ProductID";
            // 
            // ProductName
            // 
            ProductName.HeaderText = "ProductName";
            ProductName.Name = "ProductName";
            // 
            // Supplier
            // 
            Supplier.HeaderText = "Supplier";
            Supplier.Name = "Supplier";
            // 
            // Category
            // 
            Category.HeaderText = "Category";
            Category.Name = "Category";
            // 
            // QuantityPerUnit
            // 
            QuantityPerUnit.HeaderText = "QuantityPerUnit";
            QuantityPerUnit.Name = "QuantityPerUnit";
            // 
            // UnitPrice
            // 
            UnitPrice.HeaderText = "UnitPrice";
            UnitPrice.Name = "UnitPrice";
            // 
            // UnitsInStock
            // 
            UnitsInStock.HeaderText = "UnitsInStock";
            UnitsInStock.Name = "UnitsInStock";
            // 
            // UnitsOnOrder
            // 
            UnitsOnOrder.HeaderText = "UnitsOnOrder";
            UnitsOnOrder.Name = "UnitsOnOrder";
            // 
            // ReorderLevel
            // 
            ReorderLevel.HeaderText = "ReorderLevel";
            ReorderLevel.Name = "ReorderLevel";
            // 
            // Discontinued
            // 
            Discontinued.HeaderText = "Discontinued";
            Discontinued.Name = "Discontinued";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Cursor = Cursors.Hand;
            label1.Location = new Point(12, 123);
            label1.Name = "label1";
            label1.Size = new Size(100, 15);
            label1.TabIndex = 24;
            label1.Text = "manage products";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(432, 41);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(30, 28);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 41;
            pictureBox1.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Cursor = Cursors.Hand;
            label2.Location = new Point(468, 23);
            label2.Name = "label2";
            label2.Size = new Size(86, 15);
            label2.TabIndex = 40;
            label2.Text = "search product";
            // 
            // smallTextBox1
            // 
            smallTextBox1.BackColor = Color.Transparent;
            smallTextBox1.BorderColor = Color.FromArgb(180, 180, 180);
            smallTextBox1.CustomBGColor = Color.White;
            smallTextBox1.Font = new Font("Tahoma", 11F, FontStyle.Regular, GraphicsUnit.Point);
            smallTextBox1.ForeColor = Color.DimGray;
            smallTextBox1.Location = new Point(468, 41);
            smallTextBox1.MaxLength = 32767;
            smallTextBox1.Multiline = false;
            smallTextBox1.Name = "smallTextBox1";
            smallTextBox1.ReadOnly = false;
            smallTextBox1.Size = new Size(164, 28);
            smallTextBox1.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            smallTextBox1.TabIndex = 39;
            smallTextBox1.TextAlignment = HorizontalAlignment.Left;
            smallTextBox1.UseSystemPasswordChar = false;
            // 
            // Product
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(655, 377);
            Controls.Add(pictureBox1);
            Controls.Add(label2);
            Controls.Add(smallTextBox1);
            Controls.Add(backButton);
            Controls.Add(bigLabel1);
            Controls.Add(DeleteCategory);
            Controls.Add(AditProduct);
            Controls.Add(AddProduct);
            Controls.Add(poisonDataGridView1);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Product";
            Text = "Product";
            ((System.ComponentModel.ISupportInitialize)poisonDataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label backButton;
        private ReaLTaiizor.Controls.BigLabel bigLabel1;
        private ReaLTaiizor.Controls.HopeRoundButton DeleteCategory;
        private ReaLTaiizor.Controls.HopeRoundButton AditProduct;
        private ReaLTaiizor.Controls.HopeRoundButton AddProduct;
        private ReaLTaiizor.Controls.PoisonDataGridView poisonDataGridView1;
        private Label label1;
        private DataGridViewTextBoxColumn ProductID;
        private DataGridViewTextBoxColumn ProductName;
        private DataGridViewTextBoxColumn Supplier;
        private DataGridViewTextBoxColumn Category;
        private DataGridViewTextBoxColumn QuantityPerUnit;
        private DataGridViewTextBoxColumn UnitPrice;
        private DataGridViewTextBoxColumn UnitsInStock;
        private DataGridViewTextBoxColumn UnitsOnOrder;
        private DataGridViewTextBoxColumn ReorderLevel;
        private DataGridViewTextBoxColumn Discontinued;
        private PictureBox pictureBox1;
        private Label label2;
        private ReaLTaiizor.Controls.SmallTextBox smallTextBox1;
    }
}