﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WarehouseManager.UI.Forms.Suppliers;

namespace WarehouseManager.UI.Forms.Products
{
    public partial class Product : Form
    {
        public Product()
        {
            InitializeComponent();
        }

        private void AddProduct_Click(object sender, EventArgs e)
        {
            AddProduct pro = new AddProduct();
            pro.Show();
        }
    }
}
