﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WarehouseManager.Data.DataModels;

namespace WarehouseManager.Repository.Contracts
{
    public interface IProducts 
    {
       
        IEnumerable<Products> GetProducts();
        int insert(Products products);
        int delete(Products ProductID);
        int update(Products products);


    }
}
