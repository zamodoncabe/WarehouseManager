﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WarehouseManager.Data.DataModels;

namespace WarehouseManager.Repository.Contracts
{
    public interface ICategories
    {
        IEnumerable<Categories> GetCategories();
        bool insert(Categories categories);
        bool delete(Categories categries);
        bool update(Categories categories);

    }
}
