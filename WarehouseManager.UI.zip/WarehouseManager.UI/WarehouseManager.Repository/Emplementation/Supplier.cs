﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WarehouseManager.Data;
using WarehouseManager.Data.DataModels;
using WarehouseManager.Repository.Contracts;
using Dapper;
using System.Data;
using Microsoft.Data.SqlClient;


namespace WarehouseManager.Repository.Emplementation
{
    public class Supplier : ISupplier
    {
        private readonly IConfiguration _configuration;

         IEnumerable<Data.DataModels.Supplier> ISupplier.GetSuppliers()
        {
            using IDbConnection db = new SqlConnection(Extensions.connectionString);
            if (db.State == ConnectionState.Closed)
                db.Open();
            return (IEnumerable<Data.DataModels.Supplier>)db.Query<Supplier>("select SupplierID, CompanyName, ContactName, ContactTitle, Address, City, Region, PostalCode, Country, Phone, Fax, HomePage from Suppliers", commandType: CommandType.Text);

        }

        public int insert(Data.DataModels.Supplier supplier)
        {
            throw new NotImplementedException();
        }

        public int delete(Data.DataModels.Supplier SupplierID)
        {
            throw new NotImplementedException();
        }

        public int update(Data.DataModels.Supplier supplier)
        {
            throw new NotImplementedException();
        }

        public object GetSuppliers()
        {
            throw new NotImplementedException();
        }
    }
}
