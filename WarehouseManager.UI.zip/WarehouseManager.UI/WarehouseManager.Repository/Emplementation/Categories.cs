﻿using System.Data;
using WarehouseManager.Data;
using Dapper;
using WarehouseManager.Repository.Contracts;
using Microsoft.Data.SqlClient;

namespace WarehouseManager.Repository.Emplementation
{
    public class Categories : ICategories
    {
        public bool delete(Data.DataModels.Categories categries)
        {
            throw new NotImplementedException();
        }

        public bool insert(Data.DataModels.Categories categories)
        {
            throw new NotImplementedException();
        }

        public bool update(Data.DataModels.Categories categories)
        {
            throw new NotImplementedException();
        }

        IEnumerable<Data.DataModels.Categories> ICategories.GetCategories()
        {
            using IDbConnection db = new SqlConnection(Extensions.connectionString);
            if (db.State == ConnectionState.Closed)
                db.Open();
            return (IEnumerable<Data.DataModels.Categories>)db.Query<Categories>("select CategoryID, CategoryName, Description, Picture from Categories", commandType: CommandType.Text);

        }

    }
}
