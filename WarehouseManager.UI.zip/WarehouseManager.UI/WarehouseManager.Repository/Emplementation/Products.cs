﻿using Microsoft.Data.SqlClient;
using System.Data;
using WarehouseManager.Data;
using WarehouseManager.Data.DataModels;
using Dapper;
using WarehouseManager.Repository.Contracts;

namespace WarehouseManager.Repository.Emplementation
{
    public class Products : IProducts
    {


        public IEnumerable<Data.DataModels.Products> GetProducts()
        {
            using IDbConnection db = new SqlConnection(Extensions.connectionString);
            if (db.State == ConnectionState.Closed)
                db.Open();
            return (IEnumerable<Data.DataModels.Products>)db.Query<Products>("select ProductID,ProductName, SupplierID, CategoryID, QuantityPerUnit, UnitPrice, UnitsInStock, UnitsOnOrder, ReorderLevel, Discontinued from Products", commandType: CommandType.Text);

        }
        public int insert(Data.DataModels.Products products)
        {
            throw new NotImplementedException();
        }

        public int delete(Data.DataModels.Products ProductID)
        {
            throw new NotImplementedException();
        }

        public int update(Data.DataModels.Products products)
        {
            throw new NotImplementedException();
        }

        

      
    }
}
