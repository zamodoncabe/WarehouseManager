﻿namespace WarehouseManager.Service
{
    public class Class1
    {

    }
}